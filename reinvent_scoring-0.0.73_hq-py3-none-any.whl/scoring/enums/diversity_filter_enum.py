from dataclasses import dataclass


@dataclass(frozen=True)
class DiversityFilterEnum:
    IDENTICAL_TOPOLOGICAL_SCAFFOLD = "IdenticalTopologicalScaffold"
    IDENTICAL_MURCKO_SCAFFOLD = "IdenticalMurckoScaffold"
    SCAFFOLD_SIMILARITY = "ScaffoldSimilarity"
    SCAFFOLD_SIMILARITY_TEST = "ScaffoldSimilarityTest"
    NO_FILTER = "NoFilter"
    MUCKO_MORGAN_TANIMOTO = "MurckoMorganFPTanimoto"
