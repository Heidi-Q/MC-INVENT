# from reinvent_scoring.scoring.score_components.aizynth.building_block_availability_component import \
#     BuildingBlockAvailabilityComponent
# from reinvent_scoring.scoring.score_components.aizynth.aizynth_test import AizynthTest# \
# BuildingBlockAvailabilityComponent
# from reinvent_scoring.scoring.score_components.aizynth.aizynth_rascore import AizynthRAScore
# from reinvent_scoring.scoring.score_components.aizynth.aizynth_connector_rascore import AizynthConnectorRAScore
from reinvent_scoring.scoring.score_components.aizynth.recap_connector_rascore import RecapConnectorRAScore