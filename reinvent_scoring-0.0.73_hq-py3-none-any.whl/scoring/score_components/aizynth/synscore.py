from typing import List

import numpy as np

from reinvent_scoring.scoring.component_parameters import ComponentParameters
from reinvent_scoring.scoring.score_components.base_score_component import BaseScoreComponent
from reinvent_scoring.scoring.score_summary import ComponentSummary
import os
import pickle
from rdkit import Chem#, DataStructs
# from rdkit.DataStructs import cDataStructs
from rdkit.Chem import BRICS, Recap, AllChem, rdMolDescriptors, FragmentOnBonds, GetMolFrags#, MolFromSmiles, MolFromSmarts, MolToSmiles#, FindMolChiralCenters, GetDistanceMatrix
from rdkit.Chem.AllChem import ReplaceSubstructs
from rdkit.Geometry.rdGeometry import Point3D
# import re
from rdkit.Chem import rdChemReactions as Reactions
from joblib import Parallel,delayed

cleavage_frags = {
    '[#6:1][NX3;!$(NC=O);!$(NS=O):2][C:3]=[O:4]':['[H]','[OX2H1]'], # NHCOO_cd, condensation NCO
    '[#6:1][NX3:2][#6;!$(C=O):3]':['[H]','[I]'], # CXNH_Nu, X_Nu_substitution NC!O
    '[#6;!$(C=O):1][OX2:2][#6;!$(C=O):3]':['[H]','[I]'], # CXCOH_Nu, C_O_coupling
    # '[#6:1][cX3:2]':['[Br]','[BX3]([OX2])([OX2])'], # BOOCX_Nu, mitsunobu
}


"""AiZynth one-step synthesis building block availability.

Score is the ratio between
the number of reactants in stock
and the number of all reactants.

If a molecule can be synthesized using different reactions,
with different sets of reactants,
the maximum ratio is used.

This scoring component uses AiZynthFinder Expansion interface:
https://molecularai.github.io/aizynthfinder/python_interface.html#expansion-interface
"""


# def calculate_score(molecules: List, step=-1) -> ComponentSummary:
#     valid_smiles = self._chemistry.mols_to_smiles(molecules)
#     score = score_smiles(valid_smiles)  # This is the main calculation.
#     # score_summary = ComponentSummary(total_score=score, parameters=self.parameters)#, raw_score=score
#     return score_summary
#
# def score_smiles(smiles: List[str]) -> np.ndarray:
#     scores = [predict_rascore(prbmol) for prbmol in smiles]
#     return np.array(scores) # np.array(transformed_scores)
def k_geodis(value, high, low, k):
    try:
        return 1 / (1 + 10 ** (k * (value - (high + low) / 2) * 10 / (high - low)))
    except:
        return 0

def is_mac(molecule):
    # not_mac = False
    mac = []
    if molecule:
        rings = molecule.GetRingInfo().AtomRings()
        ring_numatom = [len(k) for k in rings]
        mac_num = [k for k in ring_numatom if k >10]
        if len(mac_num) >0:
            mac.append(molecule)
    return len(mac)

def get_ecfp(mol): #smiles):
    """
    Converts SMILES into a counted ECFP6 vector with features.

    :param smiles: SMILES representation of the moelcule of interest
    :type smiles: str
    :return: ECFP6 counted vector with features
    :rtype: np.array
    """
    # mol = Chem.MolFromSmiles(smiles)
    fp = AllChem.GetMorganFingerprint(mol, 3, useCounts=True, useFeatures=False)
    size = 2048
    arr = np.zeros((size,), np.int32)
    for idx, v in fp.GetNonzeroElements().items():
        nidx = idx % size
        arr[nidx] += int(v)
    return arr


def predict_rascore(smiles):#prbmol):#
    # scores = []
    scores=dict()
    prbmol = Chem.MolFromSmiles(smiles)
    if not prbmol:
        return 0
    # clvs = [Chem.MolFromSmarts(clv) for clv in cleavage_frags.keys()]
    for smt, reps in cleavage_frags.items():
        clv = Chem.MolFromSmarts(smt)
        # try:
        matches = prbmol.GetSubstructMatches(clv)
        for match in matches:
            geodis = 100
            bond_idx = prbmol.GetBondBetweenAtoms(match[1],match[2]).GetIdx()
            clvmol = Chem.FragmentOnBonds(prbmol, (bond_idx,))## 0#dummyLabels=[(70, 71)])#
            if len(Chem.GetMolFrags(clvmol, asMols=True)) > 1:
                continue
            lnrmol = Chem.GetMolFrags(clvmol, asMols=True)[0]
            if is_mac(lnrmol):
                continue
            try:
            # dm_neighbors = [atom.GetNeighbors()[0] for atom in lnrmol.GetAtoms() if atom.GetSymbol() == '*']
                for atom in lnrmol.GetAtoms():
                    if atom.GetSymbol() == '*':
                        neigh_atom = atom.GetNeighbors()[0]
                        if neigh_atom.GetSymbol() in ['O','N']:
                            atom.SetIsotope(70)
                            neigh_atom.SetProp("molAtomMapNumber", '70')
                        elif neigh_atom.GetSymbol() == 'C':
                            atom.SetIsotope(71)
                            neigh_atom.SetProp("molAtomMapNumber", '71')
                repmol = lnrmol
                # for rpa, rpb in reps:
                repmol = Chem.ReplaceSubstructs(repmol, Chem.MolFromSmarts('[70*]'), Chem.MolFromSmarts(reps[0]), replaceAll=True)[0]
                repmol = Chem.ReplaceSubstructs(repmol, Chem.MolFromSmarts('[71*]'), Chem.MolFromSmarts(reps[1]), replaceAll=True)[0]
                if Chem.MolToSmiles(repmol).count('*')>0:
                    print('rep false')
                    continue

                i, j = [atom.GetIdx() for atom in repmol.GetAtoms() if
                        atom.HasProp("molAtomMapNumber") and atom.GetProp("molAtomMapNumber") in ['70', '71']]

                adhmol = Chem.AddHs(Chem.RemoveHs(repmol))
                if not adhmol:
                    print('adhmol null!')
                    continue
                AllChem.EmbedMultipleConfs(adhmol, numConfs=10, numThreads=40)  # useRandomCoords=True)#cids =

                opt_result = AllChem.MMFFOptimizeMoleculeConfs(adhmol, numThreads=40, maxIters=800)
            except:
                continue
            # opt_energy = [res[1] for res in opt_result]
            # idx = opt_energy.index(min(opt_energy))
            # opt_energy = [idx for idx,res in enumerate(opt_result) if res[0] == 0]
            for idx, res in enumerate(opt_result):
                if res[0] == 0:
                    conf = adhmol.GetConformer(idx)
                    geodis = conf.GetAtomPosition(i).Distance(conf.GetAtomPosition(j))
                    if geodis <= 2.5:
                        break
            rmhmol = Chem.RemoveHs(adhmol)
            res = Recap.RecapDecompose(rmhmol)
            smt_scores = []
            for frag in res.GetLeaves().keys():
                fragmol=Chem.MolFromSmiles(frag)
                arr = get_ecfp(fragmol)
                proba = xgb_model.predict_proba(arr.reshape(1, -1))
                smt_scores.append(proba[0][1])

            # k_geodis = 3/geodis if geodis >3 else 1
            weight = k_geodis(geodis, 7.5, 2.5, 0.4)
            if smt_scores:
                clv_score = weight * np.mean(smt_scores)
                # # scores.append(clv_score) # if smt_scores else 0
                # scores[clv_score]=geodis

                if Chem.MolToSmiles(rmhmol):
                    clv_smi = f'{smiles}\t{Chem.MolToSmiles(rmhmol)}\t{geodis}\t{res.GetLeaves().keys()}\t{str(smt_scores)}'
                    scores[clv_score]=clv_smi
                    # print(clv_smi,clv_score)
                # if clv_score > 0.8:
                # print(Chem.MolToSmiles(rmhmol),res.GetLeaves().keys(),smt_scores,geodis,clv_score)
            else:
                pass
                # # scores.append(0)
                # scores[clv_score] = geodis
            # score.append(proba[0][1])

        # except Exception as e:
        #     print('calc gd false', e)
        #     continue
    # rascore = np.max(scores) if scores else 0
    if scores:
        rascore = max(list(scores.keys()))
        # print(f'BestRuslt: {scores[rascore]}\t{rascore}\n')
        # print(rascore)
        # print(scores[rascore].split('\t')[2])
        with open('./chembl_macrocycles_rascore.csv','a')as w:
            w.write(smiles+','+scores[rascore].split('\t')[2]+'\n')
        if rascore < 0:
        #     pass
            print()
        return rascore
    else:
        return 0
    #     sc_k = np.max(list(scores.keys()))
    #     # rascore = np.max(scores)
    #     geo_v = scores[sc_k]
    # else:
    #     geo_v = 100.0
    # print(sc_k)
    # print(geo_v)
    # return geo_v#rascore # sa_score[0] * sa_score[1]
            # prbmol.GetBondBetweenAtoms(match[0], match[1]).GetBondType()

# try:
#     i, j = [atom.GetIdx() for atom in repmol.GetAtoms() if
#             atom.HasProp("molAtomMapNumber") and atom.GetProp("molAtomMapNumber") in ['70','71']]
#
#     adhmol = Chem.AddHs(Chem.RemoveHs(repmol))
#     cids = AllChem.EmbedMultipleConfs(adhmol, numThreads=40)#useRandomCoords=True)
#     opt_result = AllChem.MMFFOptimizeMoleculeConfs(adhmol, numThreads=40, maxIters=1000)
#     opt_energy = [res[1] for res in opt_result]
#     idx = opt_energy.index(min(opt_energy))
#     # for idx, res in enumerate(opt_energy):
#     conf = adhmol.GetConformer(idx)
#     geodis = conf.GetAtomPosition(i).Distance(conf.GetAtomPosition(j))


# def __init__(self, parameters: ComponentParameters):
#     super().__init__(parameters)
# self._xgb_scorer = RAscore_XGB.RAScorerXGB().predict(imatinib_mesylate)
refmol = Chem.MolFromSmiles("COc(c1)ccc2c1ncnc2Nc3cccc(Cl)c3") #self.parameters.specific_parameters.get(self.component_specific_parameters.SMILES, [])
# self.refmol = self._chemistry.smile_to_mol(refsmiles)
HERE = os.path.abspath(os.path.dirname(__file__))
MODEL = os.path.join(HERE, "model.pkl")
# model_path = self.parameters.specific_parameters.get(self.component_specific_parameters.MODEL_PATH, [])
# if model_path:
#     self.xgb_model = pickle.load(open(model_path, "rb"))
# else:
xgb_model = pickle.load(open(MODEL, "rb"))
# test_smiles = "COc1cc2ncnc3c2cc1NCC(O)COCC(=O)NCc1ccc(Cl)cc1N3"#"COc1cc2ncnc3c2cc1OCCOCC(CN(C)COS)NCc1ccc(Cl)cc1N3" # "COc1cc2ncnc3c2cc1NCC(O)COCC(=O)NCc1ccc(Cl)cc1N3"
test_smiles1 = 'COc(c1)c(CCN2CCN=C2NCC(NC3)=O)cc4c1ncnc4Nc5c3ccc(Cl)c5'
# smi_100 = 'COc1cc2ncnc3c2cc1NCC(O)COCC(=O)NCc1ccc(Cl)cc1N3'
# smi1 = 'COc1cc2ncnc3c2cc1NCC(O)COCC(=O)NCc1ccc(Cl)cc1N3'
# smi2 = 'COc1cc2ncnc3c2cc1C1COCCN1CC(O)OCNCc1ccc(Cl)cc1N3'
# smi3 = 'COc1cc2ncnc3c2cc1OCC1CCN1CNC(=O)NCCc1ccc(Cl)cc1N3'
# smi4 = 'COc1cc2ncnc3c2cc1CCN1CCN=C1NCC(=O)NCc1ccc(Cl)cc1N3'
smi1='COC1=C(NCNC(NC[C@@H](NCC2=CC=C(C=C2N3)Cl)CN)=O)C=C4C3=NC=NC4=C1'#7u99
smi2='COC(NC1=CC=C(C2=CC=NC([C@H](N3CCC(C4=C(C(Cl)=CC=C4F)F)=CC3=O)N5)=C2)C([C@@H]6N[C@H](CC6)C5=O)=C1)=O'#6w50
smi2='COC(=O)Nc(c1)ccc(c1[C@@H]23)c4cc(ncc4)[C@@H](NC(=O)[C@H](N3)CC2)N(CC5)C(=O)C=C5c6c(F)c(Cl)ccc6F'
smi3='O=C(C1NCC1)N(CCC2)COC(C=C3N(C2=C4C)C5=C4C(CC(C)(C)C5)=O)=C(C=C3)C(N)=O'#3rkz
smi3 = 'O=C(C1NCC1)N(CCC2)COC(C=C3N(C2=C4C)C5=C4C(CC(C)(C)C5)=O)=C(C=C3)C(N)=O'
smi7u99='COC1=C2C=C(C(NC3=CC(Cl)=CC=C3OCCOCCOCCO2)=NC=N4)C4=C1'
smi6w50='FC1=CC=C(C(F)=C1C(CCN2[C@@H](CCC[C@H]3C)C4=CC(C5=CC=C(NC(OC)=O)C=C5NC3=O)=CC=N4)=CC2=O)Cl'
smi3rkz='O=C([C@@H](N)C)N(CCC1=C(C2=C(CC(C)(CC2=O)C)N31)C)C[C@H]([C@@H](NC4=CC3=CC=C4C(N)=O)C)C'
smi2j9m='c12c(Br)cnc(n1)Nc3cc(ccc3)S(=O)(=O)NCCCN2'
smi8h6p='O=C(NC[C@H](C1)C[C@@H]1OC2)O[C@@H](C3)CC[C@@H]3C4=CC(NC5=NC2=CC=C5)=NN4'#'O=C(NCCCNC1)O[C@@H](C2)CC[C@@H]2C3=CC(NC4=NC1=CC=C4)=NN3'
# geo = predict_rascore(smi7u99)

# fp1='/mnt/home/qiuhaodi/new_data/6W50_pp4'#rmsd_azra1'
fp2='/data/qiuhaodi/reinvent/Reinvent-master-copy/paper/chemblmacros_splrmi_macrocycles_props.csv'#_macrocycles_filtered.csv'#'/mnt/home/qiuhaodi/new_data/3RKZ_pp1/results/scaffold_memory.csv'
# with open(f'{fp}/sampled.sdf','r')as f:
out1 = './chembl_macrocycles_rascore.csv'#'./3rkz_rascore.csv'
# df1=Chem.SDMolSupplier(f'{fp1}/sampled.sdf')
# mols = [mol for mol in df1 if mol]
smis=[]
with open(fp2,'r')as f:
    for line in f.readlines():
        smi = line.strip().split(',')[0]#2
        smis.append(smi)
smis=smis[869:]
for smi in smis:
    try:
        rascore = predict_rascore(smi)
        # rascores.append(str(rascore))
    except:
        pass


