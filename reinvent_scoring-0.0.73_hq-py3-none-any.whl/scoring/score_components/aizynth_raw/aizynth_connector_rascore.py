from typing import List

import numpy as np

from reinvent_scoring.scoring.component_parameters import ComponentParameters
from reinvent_scoring.scoring.score_components.base_score_component import BaseScoreComponent
from reinvent_scoring.scoring.score_summary import ComponentSummary

import os
import pickle
from rdkit import Chem, DataStructs
# from rdkit.DataStructs import cDataStructs
from rdkit.Chem import AllChem, rdMolDescriptors, FragmentOnBonds, GetMolFrags, MolFromSmiles, MolFromSmarts, MolToSmiles#, FindMolChiralCenters, GetDistanceMatrix
from rdkit.Chem.AllChem import ReplaceSubstructs
# import re
from rdkit.Chem import rdChemReactions as Reactions

default_rxns = [
"[#7;A;H1,H2;!$(NC=O):1].[#6;A:3][#17,#35,#53:2]>>[#6;A:3][#7;A:1]", # 1
"[#7;A;H1,H2;!$(NC=O):1].[n:4]:[c:3]-[F,Cl,Br,I:2]>>[#7;A:1][c:3]:[n:4]", # 2
"[#7;A;H1,H2;!$(NC=O):1].[H:6][#8:5]-[#6:3](-[#6:2])=[O:4]>>[#6:2]-[#6:3]([#7;A:1])=[O:4]", # 3
"[#7;A;H1,H2;!$(NC=O):1].[H:3][#6:2]([#6;A:5])=[O:4]>>[H:3][#6:2]([#6;A:5])[#7;A:1]", # 4
"[#7;A;H1,H2;!$(NC=O):1].[#6;A:5][#6:2]([#6;A:3])=[O:4]>>[#6;A:5][#6:2]([#6;A:3])[#7;A:1]", #5
"[cH1,$(C=C):1].[#6;a:2]-[F,Cl,Br,I:3]>>[#6;a:2]-[cH1,$(C=C):1]", # 6 Heck
"[#6;a:1]-[#8H1:2].[#6;!$(*=O):5][#8,#16;A;H1:4]>>[#6:5]-[#8,#16:4]-[#6;a:1]", # 7 mitsunobu1
"[#6;a:1]-[#8H1:2].[#6;!$(*=O):5][#7;A;H1,H2:4]>>[#6:5]-[#7:4]-[#6;a:1]", # 8 mitsunobu2
"[#6;!$(C=O):1][#8;AH1;!$(OC=O):2].[#6;a:5]-[#17,#35,#53:4]>>[#6;a:5]-[#8:2]-[#6:1]", # 9 couplingO
"[#6;!$(C=O)][#7;A;H1,H2;!$(NC=O):2].[#6;a:5]-[#17,#35,#53:4]>>[#6;a:5]-[#7:2]-[#6:1]", # 10 couplingN
"[#6;!$(C=O)][#16;AH1;!$(SC=O):2].[#6;a:5]-[#17,#35,#53:4]>>[#6;a:5]-[#16:2]-[#6:1]", # 11 couplingS
"[#6;A:1][#17,#35,#53:2].[#6;a:4]-[#17,#35,#53:3]>>[#6;A:1][#6;a:4]", # couplingCC
"[#6;a:1]-[#17,#35,#53:2].[#6;a:4]-[#17,#35,#53:3]>>[#6;a:1]-[#6;a:4]", #couplingCc
"[#7;AH2;!$(NC=O):1].[#17,#35,#53:4][#6;A;!R:7][#7;A;!R:6][#6;A;!R:5][#17,#35,#53:3]>>[#6:7]-1-[#7:6]-[#6:5]-[#7:1]-1", # cycling4
"[#7;AH2;!$(NC=O):1].[#17,#35,#53:4][#6;A;!R:8][#6;A;!R:7][#7;A;!R:6][#6;A;!R:5][#17,#35,#53:3]>>[#6:7]-1-[#6:8]-[#7:1]-[#6:5]-[#7:6]-1", # cycling5
"[#7;AH2;!$(NC=O):1].[#17,#35,#53:4][#6;A;!R:9][#6;A;!R:8][#7;A;!R:7][#6;A;!R:6][#6;A;!R:5][#17,#35,#53:3]>>[#6:8]-1-[#6:9]-[#7:1]-[#6:5]-[#6:6]-[#7:7]-1", #cycling6
"[#6:4]-[#5:2](-[#8:1])-[#8:3].[#6:6]-[F,Cl,Br,I:5]>>[#6:4]-[#6:6]", #BX
"[*:6]-[#7:1]=[N+:2]=[#7-:3].[*:7][C:4]#[CH1:5]>>[*:6]-[#7:1]-1-[#6:5]=[#6:4](-[*:7])-[#7:3]=[#7:2]-1", # clicke triazole
]

class AizynthConnectorRAScore(BaseScoreComponent):
    """AiZynth one-step synthesis building block availability.

    Score is the ratio between
    the number of reactants in stock
    and the number of all reactants.

    If a molecule can be synthesized using different reactions,
    with different sets of reactants,
    the maximum ratio is used.

    This scoring component uses AiZynthFinder Expansion interface:
    https://molecularai.github.io/aizynthfinder/python_interface.html#expansion-interface
    """

    def __init__(self, parameters: ComponentParameters):
        super().__init__(parameters)
        # self._xgb_scorer = RAscore_XGB.RAScorerXGB().predict(imatinib_mesylate)
        refsmiles = self.parameters.specific_parameters.get(self.component_specific_parameters.SMILES, [])
        self.refmol = self._chemistry.smile_to_mol(refsmiles)
        HERE = os.path.abspath(os.path.dirname(__file__))
        MODEL = os.path.join(HERE, "model.pkl")
        model_path = self.parameters.specific_parameters.get(self.component_specific_parameters.MODEL_PATH, [])
        if model_path:
            self.xgb_model = pickle.load(open(model_path, "rb"))
        else:
            self.xgb_model = pickle.load(open(MODEL, "rb"))

    def calculate_score(self, molecules: List, step=-1) -> ComponentSummary:
        valid_smiles = self._chemistry.mols_to_smiles(molecules)
        score = self._score_smiles(valid_smiles)  # This is the main calculation.
        score_summary = ComponentSummary(total_score=score, parameters=self.parameters)#, raw_score=score

        return score_summary

    def _score_smiles(self, smiles: List[str]) -> np.ndarray:
        scores = [self._predict_rascore(prbmol) for prbmol in smiles]

        # transform_params = self.parameters.specific_parameters.get(
        #     self.component_specific_parameters.TRANSFORMATION, {}
        # )
        # transformed_scores = self._transformation_function(scores, transform_params)
        return np.array(scores) # np.array(transformed_scores)
        # results = [self._predict_rascore(smi) for smi in smiles]
        #
        # return np.array(results)

    def _predict_rascore(self, smiles):
        # scores = []
        refmol = self.refmol
        prbmol = mw0 = mw1  = Chem.MolFromSmiles(smiles)
        # prbmol = mw0 = mw1 = self._soft_check(mol)
        # matches = prbmol.GetSubstructMatches(refmol, uniquify=True)[0]
        atom_pair_0 = [atom.GetIdx()  for atom in prbmol.GetAtoms() if
                        atom.HasProp("molAtomMapNumber") and atom.GetProp("molAtomMapNumber") == '0']
        atom_pair_1 = [atom.GetIdx() for atom in prbmol.GetAtoms() if
                        atom.HasProp("molAtomMapNumber") and atom.GetProp("molAtomMapNumber") == '1']
        bond_0 = prbmol.GetBondBetweenAtoms(atom_pair_0[0],atom_pair_0[1]).GetIdx()
        bond_1 = prbmol.GetBondBetweenAtoms(atom_pair_1[0],atom_pair_1[1]).GetIdx()
        bond_pair = [bond_0, bond_1]
        # bond_pair = [prbmol.GetBondBetweenAtoms(atom_pair_0[0],atom_pair_0[1]).GetIdx(), prbmol.GetBondBetweenAtoms(atom_pair_1[0],atom_pair_1[1]).GetIdx()]
        fragments = FragmentOnBonds(prbmol, bond_pair)
        fragment_mols = GetMolFrags(fragments, asMols=True)
        # f0mol = Chem.RWMol(mw0)# as :
        # f0mol.RemoveBond(atom_pair_0[0],atom_pair_0[1])
        # f1mol =  Chem.RWMol(mw1)# as mw1:
        # f1mol.RemoveBond(atom_pair_1[0],atom_pair_1[1])
        # f0_mol = self._soft_check(f0mol)
        # f1_mol = self._soft_check(f1mol)
        # atom.ClearProp("molAtomMapNumber")#,addDummies=False
        f0mol = GetMolFrags(FragmentOnBonds(mw0, [bond_0]), asMols=True)[0]
        f1mol = GetMolFrags(FragmentOnBonds(mw1, [bond_1]), asMols=True)[0]
        f0_mol = Chem.RemoveHs(
            ReplaceSubstructs(f0mol, Chem.MolFromSmiles('*'), Chem.MolFromSmiles('[Rb]'), True)[0])
        f1_mol = Chem.RemoveHs(
            ReplaceSubstructs(f1mol, Chem.MolFromSmiles('*'), Chem.MolFromSmiles('[Rb]'), True)[0])
        try:
            lk_mol = [frag  for frag in fragment_mols if not frag.GetSubstructMatches(refmol, uniquify=True)][0]
            lk_atom_pair = [atom.GetIdx() for atom in lk_mol.GetAtoms() if atom.HasProp("molAtomMapNumber")]
            ref_mol = [frag for frag in fragment_mols if frag.GetSubstructMatches(refmol, uniquify=True)][0]
            ref_atom_pair = [atom.GetIdx() for atom in ref_mol.GetAtoms() if atom.HasProp("molAtomMapNumber")]
        except:
            return 0
        lk_rms = Chem.RemoveHs(
            ReplaceSubstructs(lk_mol, Chem.MolFromSmiles('*'), Chem.MolFromSmiles('[Rb]'), True)[0])
        sc_rms = Chem.RemoveHs(
            ReplaceSubstructs(ref_mol, Chem.MolFromSmiles('*'), Chem.MolFromSmiles('[Rb]'), True)[0])
        # lk_smiles = self._add_connector(lk_rms)
        # sc_smiles = self._add_connector(sc_rms)
        pats = [MolFromSmarts('[N][Rb]'), MolFromSmarts('[O][Rb]'),
                MolFromSmarts('[S][Rb]'), MolFromSmarts('[C](=O)[Rb]'),
                MolFromSmarts('[C][Rb]'), MolFromSmarts('[c][Rb]')]
        reps = [MolFromSmarts('[N][H]'), MolFromSmarts('[O][H]'),
                MolFromSmarts('[S][H]'), MolFromSmarts('[C](=O)[OH]'),
                MolFromSmarts('[C][Br]'), MolFromSmarts('[c][Br]')]
        # reds =
        # for mol in [lk_rms,sc_rms]:
        for pat, rep in zip(pats,reps):
            if lk_rms.GetSubstructMatch(pat):
                lk_rms = ReplaceSubstructs(lk_rms, pat, rep, True, 0)[0]
        for pat, rep in zip(pats,reps):
            if sc_rms.GetSubstructMatch(pat):
                sc_rms = ReplaceSubstructs(sc_rms, pat, rep, True, 0)[0]
        for pat, rep in zip(pats,reps):
            if f0_mol.GetSubstructMatch(pat):
                f0_mol = ReplaceSubstructs(f0_mol, pat, rep, True, 0)[0]
        for pat, rep in zip(pats,reps):
            if f1_mol.GetSubstructMatch(pat):
                f1_mol = ReplaceSubstructs(f1_mol, pat, rep, True, 0)[0]

        # if Chem.MolToSmiles(lk_rms).count('Rb')>0  or Chem.MolToSmiles(sc_rms).count('Rb')>0:
        #     for pat, rep in zip(pats, reps):
        #         if lk_rms.GetSubstructMatch(pat):
        #             lk_rms = ReplaceSubstructs(lk_rms, pat, rep, True, 0)[0]
        #     # while MolToSmiles(sc_rms).count('Rb') > 0:
        #     for pat, rep in zip(pats, reps):
        #         if sc_rms.GetSubstructMatch(pat):
        #             sc_corms = ReplaceSubstructs(sc_rms, pat, rep, True, 0)[0]
        #     if Chem.MolToSmiles(lk_rms).count('Rb') > 0 or Chem.MolToSmiles(sc_rms).count('Rb') > 0:
        #         print('replac Rb Error')
        #         return 0

        # co_linkers = self._perform_rxn(lk_smiles, sc_smiles, default_rxns, prbmol)
        # co_linkers = []
        # connectors = [(MolFromSmiles(lk_smi),MolFromSmarts(sc_smi)) for lk_smi in lk_smiles for sc_smi in sc_smiles]
        try:
            Chem.SanitizeMol(f0_mol)
            Chem.SanitizeMol(f1_mol)
        except:
            pass
        fm_fp = AllChem.GetMorganFingerprint(prbmol, 3, useCounts=True, useFeatures=False)
        f0_fp = AllChem.GetMorganFingerprint(f0_mol, 3, useCounts=True, useFeatures=False)
        f1_fp = AllChem.GetMorganFingerprint(f1_mol, 3, useCounts=True, useFeatures=False)
        flag_0 = 0
        flag_1 = 0
        co_lk_flag = 0
        rxns = [Reactions.ReactionFromSmarts(x) for x in default_rxns]
        # for conn in connectors:
        for rxn in rxns:
            reactans = rxn.RunReactants((lk_rms, sc_rms), maxProducts=100)
            if not reactans:
                continue
            # prods = reactans[0][0]
            prods = list(sum(reactans,()))
            for prod in prods:
                prod = self._soft_check(prod)

                if not prod:
                    # print('Product Error')
                    continue
                # print(MolToSmiles(prod))
                # print(MolToSmiles(prbmol))
                # print(MolToSmiles(f0_mol))
                # print(MolToSmiles(f1_mol))
                fp = AllChem.GetMorganFingerprint(prod, 3, useCounts=True, useFeatures=False)
                # if prod.GetSubstructMatch(prbmol):#DataStructs.TanimotoSimilarity(fp, fm_fp) > 0.99 or flag_0 + flag_1 == 2:
                #     print('Congratulations!!!!!!!')
                #     co_linkers.append(MolToSmiles(lk_rms))
                # elif prod.GetSubstructMatch(f0mol):#DataStructs.TanimotoSimilarity(fp, f0_fp) > 0.99:
                #     print('Flag 0 !!!!!!!')
                #     flag_0 = 1
                # elif prod.GetSubstructMatch(f1mol):#DataStructs.TanimotoSimilarity(fp, f1_fp) > 0.99:
                #     print('Flag 1 !!!!!!!')
                #     flag_1 = 1
                if DataStructs.TanimotoSimilarity(fp, fm_fp) > 0.99 :
                    co_lk_flag = 1
                    break
                    # print('Congratulations!!!!!!!')
                    # co_linkers.append(MolToSmiles(lk_rms))
                elif DataStructs.TanimotoSimilarity(fp, f0_fp) > 0.99:
                    # print('Flag 0 !!!!!!!')
                    # print(MolToSmiles(prod))
                    # print(MolToSmiles(f0_mol))
                    flag_0 = 1
                    if flag_0 + flag_1 == 2:
                        co_lk_flag = 1
                        break
                        # print('Congratulations!!!!!!!')
                        # co_linkers.append(MolToSmiles(lk_rms))
                elif DataStructs.TanimotoSimilarity(fp, f1_fp) > 0.99:
                    # print('Flag 1 !!!!!!!')
                    # print(MolToSmiles(prod))
                    # print(MolToSmiles(f1_mol))
                    flag_1 = 1
                    if flag_0 + flag_1 == 2:
                        co_lk_flag = 1
                        break
                        # print('Congratulations!!!!!!!')
                        # co_linkers.append(MolToSmiles(lk_rms))
        # co_linkers = set([co for co in co_linkers if co])
        # if not co_linkers:
        #     print('NO COLINKERS')
        #     return 0
        #
        # for co_lk in co_linkers:
        #     arr = self._get_ecfp(co_lk)
        #     proba = self.xgb_model.predict_proba(arr.reshape(1, -1))
        #     scores.append(proba[0][1])
        # co_linkers = set([co for co in co_linkers if co])
        if not co_lk_flag:
            # print('NO COLINKERS')
            return 0
        try:
            Chem.SanitizeMol(lk_rms)
        except:
            return 0
        arr = self._get_ecfp(lk_rms)
        proba = self.xgb_model.predict_proba(arr.reshape(1, -1))
        # score.append(proba[0][1])
        return proba[0][1]#score

    def _add_connector(self, mol):
        # patt_NOS, patt_CO, patt_Cc = [MolFromSmarts('[Xe;$([N,O,S])]'), MolFromSmarts('[Xe;$(C(=O))]'), MolFromSmarts('[Xe;$([#6])]')]
        # rep_NOS, rep_CO, rep_Cc = [MolFromSmiles('[H]'), MolFromSmiles('[OH]'), MolFromSmiles('[F]')]
        pat_N, pat_O, pat_S, pat_CO, pat_C, pat_c = [MolFromSmarts('[N][Rb]'), MolFromSmarts('[O][Rb]'),
                MolFromSmarts('[S][Rb]'), MolFromSmarts('[C](=O)[Rb]'), MolFromSmarts('[C][Rb]'), MolFromSmarts('[c][Rb]')]
        rep_N, rep_O, rep_S, rep_CO, rep_C, rep_c = [MolFromSmarts('[N][H]'), MolFromSmarts('[O][H]'),
                MolFromSmarts('[S][H]'), MolFromSmarts('[C](=O)[OH]'), MolFromSmarts('[C][F]'), MolFromSmarts('[c][F]')]

        pats = [MolFromSmarts('[N][Rb]'), MolFromSmarts('[O][Rb]'),
                MolFromSmarts('[S][Rb]'), MolFromSmarts('[C](=O)[Rb]'),
                MolFromSmarts('[C][Rb]'), MolFromSmarts('[c][Rb]')]
        reps = [MolFromSmarts('[N][H]'), MolFromSmarts('[O][H]'),
                MolFromSmarts('[S][H]'), MolFromSmarts('[C](=O)[OH]'),
                MolFromSmarts('[C][F]'), MolFromSmarts('[c][F]')]

        while MolToSmiles(mol).count('Rb') > 0:
            # print(f"add wrong:{MolToSmiles(mol)}")
            for pat, rep in zip(pats,reps):
                if mol.GetSubstructMatch(pat):
                    # print(MolToSmiles(pat))
                    mol = ReplaceSubstructs(mol, pat, rep, True, 0)[0]

        co_smiles = MolToSmiles(mol)
        # if co_smiles.count('Rb') > 0:
        #     print(f"replace wrong:{co_smiles}")
        # co_smiles = re.sub(r'\[\S+:\d+\]', '', MolToSmiles(co_mol))
        #     return co_smiles
        # else:
        return co_smiles

    def _perform_rxn(self, lk_smiles, sc_smiles, reactions, full_mol):
        co_linkers = []
        # connectors = [(MolFromSmiles(lk_smi),MolFromSmarts(sc_smi)) for lk_smi in lk_smiles for sc_smi in sc_smiles]
        fm_fp = AllChem.GetMorganFingerprint(full_mol, 3, useCounts=True, useFeatures=False)
        rxns =  [Reactions.ReactionFromSmarts(x) for x in reactions]
        # for conn in connectors:
        for rxn in rxns:
            reactans = rxn.RunReactants((MolFromSmiles(lk_smiles),MolFromSmarts(sc_smiles)), maxProducts=1000)
            if not reactans:
                continue
            prod = reactans[0][0]
            for rxn in rxns:
                    try:
                        Chem.SanitizeMol(prod)
                        print(MolToSmiles(prod))
                    except:
                        continue
                    fp = AllChem.GetMorganFingerprint(prod, 3, useCounts=True, useFeatures=False)
                    if DataStructs.TanimotoSimilarity(fp, fm_fp) > 0.99:
                        print('Congratulations!!!!!!!')
                        co_linkers.append(MolToSmiles(lk_smiles))
        return set(co_linkers)

    def _get_ecfp(self, mol): #smiles):
        """
        Converts SMILES into a counted ECFP6 vector with features.

        :param smiles: SMILES representation of the moelcule of interest
        :type smiles: str
        :return: ECFP6 counted vector with features
        :rtype: np.array
        """
        # mol = Chem.MolFromSmiles(smiles)
        fp = AllChem.GetMorganFingerprint(mol, 3, useCounts=True, useFeatures=False)
        size = 2048
        arr = np.zeros((size,), np.int32)
        for idx, v in fp.GetNonzeroElements().items():
            nidx = idx % size
            arr[nidx] += int(v)
        return arr


    def _soft_check(self, mol):
        if not mol:
            return
        smi = Chem.MolToSmiles(mol)
        return Chem.MolFromSmiles(smi)
        # for atom in mol.GetAtoms():
        #     if atom.HasProp("molAtomMapNumber"):#atom.GetSymbol() == 'Xe':
        #         # rms = ReplaceSubstructs(mol, , repl)
        #         if atom.GetSymbol() =='N':
        #             co_mol = ReplaceSubstructs(mol, pat_N, rep_N, True, 0)[0]
        #         elif atom.GetSymbol() =='O':
        #             co_mol = ReplaceSubstructs(mol, pat_O, rep_O, True, 0)[0]
        #         elif atom.GetSymbol() =='S':
        #             co_mol = ReplaceSubstructs(mol, pat_S, rep_S, True, 0)[0]
        #         else: #if atom.GetSymbol() == 'C':
        #             CO_pairs = mol.GetSubstructMatches(MolFromSmiles('C(=O)'))
        #             CO_ls = [co if isinstance(co,int) else list(sum(CO_pairs, ())) for co in CO_pairs ]
        #             if atom.GetIdx() in CO_ls:
        #                 co_mol = ReplaceSubstructs(mol, pat_CO, rep_CO, True, 0)[0]
        #             else:
        #                 co_mol = ReplaceSubstructs(mol, pat_c, rep_c, True, 0)[0]
        #                 co_mol = ReplaceSubstructs(mol, pat_C, rep_C, True, 0)[0]
        # rms = AllChem.ReplaceSubstructs(mol, , repl)