from typing import List

import numpy as np

from reinvent_scoring.scoring.component_parameters import ComponentParameters
from reinvent_scoring.scoring.score_components.base_score_component import BaseScoreComponent
from reinvent_scoring.scoring.score_summary import ComponentSummary

import os
import pickle
from rdkit import Chem, DataStructs
# from rdkit.DataStructs import cDataStructs
from rdkit.Chem import AllChem, rdMolDescriptors, FragmentOnBonds, GetMolFrags, MolFromSmiles, MolFromSmarts, MolToSmiles#, FindMolChiralCenters, GetDistanceMatrix
from rdkit.Chem.AllChem import ReplaceSubstructs
# import re
from rdkit.Chem import rdChemReactions as Reactions

smiles = ['CCN1CC[S:0](=O)(=O)[NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[CH2:1]C1=O', 'C[N:0]1[NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[S:1](=O)(=O)N2CCN(CC2)CC1=O', 'OCC1CC2CN1[CH2:0][NH:0]c1nc(ncc1Br)Nc1ccc[c:1](c1)[CH2:1]CO2', 'O=[C:0]1[NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[CH2:1]C2CCCC1O2', 'O=[S:0]1(=O)[NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[CH2:1]N2CC1C2', 'O=C1CC2CN1C[CH2:0][NH:0]c1nc(ncc1Br)Nc1ccc[c:1](c1)[S:1]2(=O)=O', 'C[CH:0]1[NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[S:1](=O)(=O)NCCC(=O)N1C', 'O=[S:0]1(=O)CCC2CCN(C2)[C:1](=O)[c:1]2cccc(c2)Nc2ncc(Br)c(n2)[NH:0]1', 'CCN1[CH2:0][NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[NH:1]CC(=O)NCC1=O', 'O=[S:0]1(=O)[NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[CH2:1]OCC(O)CN2CCC1CC2', 'O=[C:0]1CN2CCC(CCN[S:1](=O)(=O)[c:1]3cccc(c3)Nc3ncc(Br)c(n3)[NH:0]1)CC2', 'C[C:0]1=CCCC(C)N[CH2:1][c:1]2cccc(c2)Nc2ncc(Br)c(n2)[NH:0]1', 'CN1[CH2:0][NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[CH:1]2CC(CNC(=O)C1)C2', 'C[CH:0]1CCC(=O)NC[C:1](=O)[c:1]2cccc(c2)Nc2ncc(Br)c(n2)[NH:0]1', 'CN1C2CC(OC[CH2:0][NH:0]c3nc(ncc3Br)Nc3ccc[c:1](c3)[S:1]1(=O)=O)C2(C)C', 'O=C1CN2CC[CH:0](CC2)[NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[S:1](=O)(=O)N1', 'CC[N:0]1[NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[CH2:1]N(C)C(=O)C2CCCN(C2)C1=O', 'O=[C:1]1NC2CCCC2C[CH2:0][NH:0]c2nc(ncc2Br)Nc2ccc[c:1]1c2', 'O=[C:0]1[NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[S:1](=O)(=O)C2CCN1C2', 'O=C1CN[S:0](=O)(=O)[NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[CH2:1]N1', 'O=[S:1]1(=O)CCC[C:0](F)(F)[NH:0]c2nc(ncc2Br)Nc2ccc[c:1]1c2', 'CN1C2CCN(CC2)[S:0](=O)(=O)[NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[C:1]1=O', 'C[N:1]1C(=O)CC[CH2:0][NH:0]c2nc(ncc2Br)Nc2ccc[c:1]1c2', 'O=C1C2COCCN1[CH2:0][NH:0]c1nc(ncc1Br)Nc1ccc[c:1](c1)[S:1](=O)(=O)N2', 'CC1C[CH2:0][NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[C:1](=O)CCC(=O)N1', 'NC1C(=O)N[CH2:0][NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[CH:1]2CCC1CC2', 'CC1(C)N2CCN(CC2)[C:0](=O)[NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[CH:1]1C#N', 'C[CH:1]1CNC(=O)N[S:0](=N)(=O)[NH:0]c2nc(ncc2Br)Nc2ccc[c:1]1c2', 'CC1C[S:0](=O)(=O)[NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[CH2:1]C(=O)N1', 'CC1CC[S:0](=O)(=O)[NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[CH2:1]NC(=O)N1', 'O=[C:1]1NC2COCCCN([CH2:0][NH:0]c3nc(ncc3Br)Nc3ccc[c:1]1c3)C2', 'CC1CC[N:0](C)[NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[N:1]1C', 'O=[S:0]1(=O)CCN2CC(=NO2)[NH:1][c:1]2cccc(c2)Nc2ncc(Br)c(n2)[NH:0]1', 'C[C:1]1(O)C2CCN(C2)[S:0](=O)(=O)[NH:0]c2nc(ncc2Br)Nc2ccc[c:1]1c2', 'NC1CC[CH2:0][NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[C:1]1=O', 'NC(=O)C1[CH2:0][NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[CH2:1]CC(=O)N1', 'CC12COC1O[CH2:0][NH:0]c1nc(ncc1Br)Nc1ccc[c:1](c1)[C:1]2=O', 'CC1N2CCC(CC2)[CH2:0][NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[C:1]1=O', 'CN1C(=O)N[S:0](=O)(=O)[NH:0]c2nc(ncc2Br)Nc2ccc[c:1](c2)[CH2:1]1']

default_rxns = [
"[#7;A;H1,H2;!$(NC=O):1].[#6;A:3][#17,#35,#53:2]>>[#6;A:3][#7;A:1]", # 1
"[#7;A;H1,H2;!$(NC=O):1].[n:4]:[c:3]-[F,Cl,Br,I:2]>>[#7;A:1][c:3]:[n:4]", # 2
"[#7;A;H1,H2;!$(NC=O):1].[H:6][#8:5]-[#6:3](-[#6:2])=[O:4]>>[#6:2]-[#6:3]([#7;A:1])=[O:4]", # 3
"[#7;A;H1,H2;!$(NC=O):1].[H:3][#6:2]([#6;A:5])=[O:4]>>[H:3][#6:2]([#6;A:5])[#7;A:1]", # 4
"[#7;A;H1,H2;!$(NC=O):1].[#6;A:5][#6:2]([#6;A:3])=[O:4]>>[#6;A:5][#6:2]([#6;A:3])[#7;A:1]", #5
"[cH1,$(C=C):1].[#6;a:2]-[F,Cl,Br,I:3]>>[#6;a:2]-[cH1,$(C=C):1]", # 6 Heck
"[#6;a:1]-[#8H1:2].[#6;!$(*=O):5][#8,#16;A;H1:4]>>[#6:5]-[#8,#16:4]-[#6;a:1]", # 7 mitsunobu1
"[#6;a:1]-[#8H1:2].[#6;!$(*=O):5][#7;A;H1,H2:4]>>[#6:5]-[#7:4]-[#6;a:1]", # 8 mitsunobu2
"[#6;!$(C=O):1][#8;AH1;!$(OC=O):2].[#6;a:5]-[#17,#35,#53:4]>>[#6;a:5]-[#8:2]-[#6:1]", # 9 couplingO
"[#6;!$(C=O)][#7;A;H1,H2;!$(NC=O):2].[#6;a:5]-[#17,#35,#53:4]>>[#6;a:5]-[#7:2]-[#6:1]", # 10 couplingN
"[#6;!$(C=O)][#16;AH1;!$(SC=O):2].[#6;a:5]-[#17,#35,#53:4]>>[#6;a:5]-[#16:2]-[#6:1]", # 11 couplingS
"[#6;A:1][#17,#35,#53:2].[#6;a:4]-[#17,#35,#53:3]>>[#6;A:1][#6;a:4]", # couplingCC
"[#6;a:1]-[#17,#35,#53:2].[#6;a:4]-[#17,#35,#53:3]>>[#6;a:1]-[#6;a:4]", #couplingCc
"[#7;AH2;!$(NC=O):1].[#17,#35,#53:4][#6;A;!R:7][#7;A;!R:6][#6;A;!R:5][#17,#35,#53:3]>>[#6:7]-1-[#7:6]-[#6:5]-[#7:1]-1", # cycling4
"[#7;AH2;!$(NC=O):1].[#17,#35,#53:4][#6;A;!R:8][#6;A;!R:7][#7;A;!R:6][#6;A;!R:5][#17,#35,#53:3]>>[#6:7]-1-[#6:8]-[#7:1]-[#6:5]-[#7:6]-1", # cycling5
"[#7;AH2;!$(NC=O):1].[#17,#35,#53:4][#6;A;!R:9][#6;A;!R:8][#7;A;!R:7][#6;A;!R:6][#6;A;!R:5][#17,#35,#53:3]>>[#6:8]-1-[#6:9]-[#7:1]-[#6:5]-[#6:6]-[#7:7]-1", #cycling6
"[#6:4]-[#5:2](-[#8:1])-[#8:3].[#6:6]-[F,Cl,Br,I:5]>>[#6:4]-[#6:6]", #BX
"[*:6]-[#7:1]=[N+:2]=[#7-:3].[*:7][C:4]#[CH1:5]>>[*:6]-[#7:1]-1-[#6:5]=[#6:4](-[*:7])-[#7:3]=[#7:2]-1", # clicke triazole
]

# class AizynthConnectorRAScore(BaseScoreComponent):
"""AiZynth one-step synthesis building block availability.

Score is the ratio between
the number of reactants in stock
and the number of all reactants.

If a molecule can be synthesized using different reactions,
with different sets of reactants,
the maximum ratio is used.

This scoring component uses AiZynthFinder Expansion interface:
https://molecularai.github.io/aizynthfinder/python_interface.html#expansion-interface
"""

# def __init__(self, parameters: ComponentParameters):
#     super().__init__(parameters)
    # self._xgb_scorer = RAscore_XGB.RAScorerXGB().predict(imatinib_mesylate)
refsmiles ='NC1=C(Br)C=NC(NC2=CC=CC=C2)=N1' #self.parameters.specific_parameters.get(self.component_specific_parameters.SMILES, [])
# refmol = self._chemistry.smile_to_mol(refsmiles)
HERE = os.path.abspath(os.path.dirname(__file__))
MODEL = os.path.join(HERE, "model.pkl")
# model_path = self.parameters.specific_parameters.get(self.component_specific_parameters.MODEL_PATH, [])
# if model_path:
#     self.xgb_model = pickle.load(open(model_path, "rb"))
# else:
xgb_model = pickle.load(open(MODEL, "rb"))

def calculate_score(molecules: List, step=-1) -> ComponentSummary:
    valid_smiles = self._chemistry.mols_to_smiles(molecules)
    score = _score_smiles(valid_smiles)  # This is the main calculation.
    score_summary = ComponentSummary(total_score=score, parameters=self.parameters)#, raw_score=score

    return score_summary

def _score_smiles(smiles: List[str]) -> np.ndarray:
    scores = [self._predict_rascore(prbmol) for prbmol in smiles]
    return np.array(scores) # np.array(transformed_scores)

def _predict_rascore(self, smiles):
    scores = []
    refmol = self.refmol
    prbmol = Chem.MolFromSmiles(smiles)
    # matches = prbmol.GetSubstructMatches(refmol, uniquify=True)[0]
    atom_pair_0 = [atom.GetIdx()  for atom in prbmol.GetAtoms() if
                    atom.HasProp("molAtomMapNumber") and atom.GetProp("molAtomMapNumber") == '0']
    atom_pair_1 = [atom.GetIdx() for atom in prbmol.GetAtoms() if
                    atom.HasProp("molAtomMapNumber") and atom.GetProp("molAtomMapNumber") == '1']
    bond_pair = [ prbmol.GetBondBetweenAtoms(atom_pair_0[0],atom_pair_0[1]).GetIdx(), prbmol.GetBondBetweenAtoms(atom_pair_1[0],atom_pair_1[1]).GetIdx()]
    fragments = FragmentOnBonds(prbmol, bond_pair)
    fragment_mols = GetMolFrags(fragments, asMols=True)
    # atom.ClearProp("molAtomMapNumber")
    try:
        lk_mol = [frag  for frag in fragment_mols if not frag.GetSubstructMatches(refmol, uniquify=True)][0]
        # lk_atom_pair = [atom.GetIdx() for atom in lk_mol.GetAtoms() if atom.HasProp("molAtomMapNumber")]
        ref_mol = [frag for frag in fragment_mols if frag.GetSubstructMatches(refmol, uniquify=True)][0]
        # ref_atom_pair = [atom.GetIdx() for atom in ref_mol.GetAtoms() if atom.HasProp("molAtomMapNumber")]
    except:
        return 0
    # lk_distance_matrix = GetDistanceMatrix(lk_mol)
    # lk_eflength = lk_distance_matrix[lk_atom_pair[0], lk_atom_pair[1]]
    lk_rms = Chem.RemoveHs(
        ReplaceSubstructs(lk_mol, Chem.MolFromSmiles('*'), Chem.MolFromSmiles('[Xe]'), True)[0])
    sc_rms = Chem.RemoveHs(
        ReplaceSubstructs(ref_mol, Chem.MolFromSmiles('*'), Chem.MolFromSmiles('[Xe]'), True)[0])
    lk_smiles = self._add_connector(lk_rms)
    sc_smiles = self._add_connector(sc_rms)
    if not lk_smiles or not sc_smiles:
        return 0
    co_linkers = self._perform_rxn(lk_smiles, sc_smiles, default_rxns, prbmol)
    if not co_linkers:
        return 0

    for co_lk in co_linkers:
        arr = self._get_ecfp(co_linkers)
        proba = self.xgb_model.predict_proba(arr.reshape(1, -1))
        scores.append(proba[0][1])
    return max(scores)

def _add_connector(self, mol):
    pats = [MolFromSmarts('[N][Rb]'), MolFromSmarts('[O][Rb]'),
            MolFromSmarts('[S][Rb]'), MolFromSmarts('[C](=O)[Rb]'),
            MolFromSmarts('[C][Rb]'), MolFromSmarts('[c][Rb]')]
    reps = [MolFromSmarts('[N][H]'), MolFromSmarts('[O][H]'),
            MolFromSmarts('[S][H]'), MolFromSmarts('[C](=O)[OH]'),
            MolFromSmarts('[C][F]'), MolFromSmarts('[c][F]')]
    for pat, rep in zip(pats,reps):
        co_mol = ReplaceSubstructs(mol, pat, rep, True, 0)[0]

    co_smiles = MolToSmiles(co_mol)
    if co_smiles.count('Rb') == 0:
    # co_smiles = re.sub(r'\[\S+:\d+\]', '', MolToSmiles(co_mol))
        return co_smiles
    else:
        print(co_smiles)

def _perform_rxn(self, lk_smiles, sc_smiles, reactions, full_mol):
    co_linkers = []
    # connectors = [(MolFromSmiles(lk_smi),MolFromSmarts(sc_smi)) for lk_smi in lk_smiles for sc_smi in sc_smiles]
    fm_fp = AllChem.GetMorganFingerprint(full_mol, 3, useCounts=True, useFeatures=False)
    rxns =  [Reactions.ReactionFromSmarts(x) for x in reactions]
    # for conn in connectors:
    for rxn in rxns:
        reactans = rxn.RunReactants((MolFromSmiles(lk_smiles),MolFromSmarts(sc_smiles)), maxProducts=1000)
        for product in reactans:
            for prod in product:
                try:
                    Chem.SanitizeMol(prod)
                except:
                    continue
                fp = AllChem.GetMorganFingerprint(prod, 3, useCounts=True, useFeatures=False)
                if DataStructs.TanimotoSimilarity(fp, fm_fp) > 0.99:
                    co_linkers.append(MolToSmiles(lk_smiles))
    return set(co_linkers)

def _get_ecfp(self, mol): # smiles):
    fp = AllChem.GetMorganFingerprint(mol, 3, useCounts=True, useFeatures=False)
    size = 2048
    arr = np.zeros((size,), np.int32)
    for idx, v in fp.GetNonzeroElements().items():
        nidx = idx % size
        arr[nidx] += int(v)
    return arr

