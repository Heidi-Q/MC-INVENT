from typing import List

import numpy as np

from reinvent_scoring.scoring.component_parameters import ComponentParameters
from reinvent_scoring.scoring.score_components.base_score_component import BaseScoreComponent
from reinvent_scoring.scoring.score_summary import ComponentSummary

import os
import pickle
from rdkit import Chem, DataStructs
from rdkit.Chem import AllChem, rdMolDescriptors, FragmentOnBonds, GetMolFrags#, FindMolChiralCenters, GetDistanceMatrix
from rdkit.DataStructs import cDataStructs

class AizynthRAScore(BaseScoreComponent):
    """AiZynth one-step synthesis building block availability.

    Score is the ratio between
    the number of reactants in stock
    and the number of all reactants.

    If a molecule can be synthesized using different reactions,
    with different sets of reactants,
    the maximum ratio is used.

    This scoring component uses AiZynthFinder Expansion interface:
    https://molecularai.github.io/aizynthfinder/python_interface.html#expansion-interface
    """

    def __init__(self, parameters: ComponentParameters):
        super().__init__(parameters)
        # self._xgb_scorer = RAscore_XGB.RAScorerXGB().predict(imatinib_mesylate)
        refsmiles = self.parameters.specific_parameters.get(self.component_specific_parameters.SMILES, [])
        self.refmol = self._chemistry.smile_to_mol(refsmiles)
        HERE = os.path.abspath(os.path.dirname(__file__))
        MODEL = os.path.join(HERE, "model.pkl")
        model_path = self.parameters.specific_parameters.get(self.component_specific_parameters.MODEL_PATH, [])
        if model_path:
            self.xgb_model = pickle.load(open(model_path, "rb"))
        else:
            self.xgb_model = pickle.load(open(MODEL, "rb"))

    def calculate_score(self, molecules: List, step=-1) -> ComponentSummary:
        valid_smiles = self._chemistry.mols_to_smiles(molecules)
        score = self._score_smiles(valid_smiles)  # This is the main calculation.
        score_summary = ComponentSummary(total_score=score, parameters=self.parameters)  # , raw_score=score

        return score_summary

    def _score_smiles(self, smiles: List[str]) -> np.ndarray:

        scores = [self._predict_rascore(prbmol) for prbmol in smiles]

        # transform_params = self.parameters.specific_parameters.get(
        #     self.component_specific_parameters.TRANSFORMATION, {}
        # )
        # transformed_scores = self._transformation_function(scores, transform_params)
        return np.array(scores)  # np.array(transformed_scores)
        # results = [self._predict_rascore(smi) for smi in smiles]
        #
        # return np.array(results)

    def _get_ecfp(self, mol): # smiles):
        """
        Converts SMILES into a counted ECFP6 vector with features.

        :param smiles: SMILES representation of the moelcule of interest
        :type smiles: str
        :return: ECFP6 counted vector with features
        :rtype: np.array
        """
        # mol = Chem.MolFromSmiles(smiles)
        fp = AllChem.GetMorganFingerprint(mol, 3, useCounts=True, useFeatures=False)
        size = 2048
        arr = np.zeros((size,), np.int32)
        for idx, v in fp.GetNonzeroElements().items():
            nidx = idx % size
            arr[nidx] += int(v)
        return arr

    def _predict_rascore(self, smiles):
        refmol = self.refmol
        prbmol = Chem.MolFromSmiles(smiles)
        if not prbmol:
            return False
        # match = prbmol.GetSubstructMatch(refmol)#, uniquify=True)[0]
        atom_pair_0 = [atom.GetIdx() for atom in prbmol.GetAtoms() if
                       atom.HasProp("molAtomMapNumber") and atom.GetProp("molAtomMapNumber") == '0']
        atom_pair_1 = [atom.GetIdx() for atom in prbmol.GetAtoms() if
                       atom.HasProp("molAtomMapNumber") and atom.GetProp("molAtomMapNumber") == '1']
        bond_pair = [prbmol.GetBondBetweenAtoms(atom_pair_0[0], atom_pair_0[1]).GetIdx(),
                     prbmol.GetBondBetweenAtoms(atom_pair_1[0], atom_pair_1[1]).GetIdx()]
        fragments = FragmentOnBonds(prbmol, bond_pair)
        fragments = GetMolFrags(fragments, asMols=True)
        # atom.ClearProp("molAtomMapNumber")
        # try:
        lk_mol = [frag for frag in fragments if not frag.GetSubstructMatches(refmol, uniquify=True)][0]
        lk_atom_pair = [atom.GetIdx() for atom in lk_mol.GetAtoms() if atom.HasProp("molAtomMapNumber")]
        ref_mol = [frag for frag in fragments if frag.GetSubstructMatches(refmol, uniquify=True)][0]
        ref_atom_pair = [atom.GetIdx() for atom in ref_mol.GetAtoms() if atom.HasProp("molAtomMapNumber")]
        # except:
        #     return False

        rms = Chem.RemoveHs(AllChem.ReplaceSubstructs(lk_mol, Chem.MolFromSmiles('*'), Chem.MolFromSmiles('[H]'), True)[0])
        arr = self._get_ecfp(rms)
        proba = self.xgb_model.predict_proba(arr.reshape(1, -1))
        return proba[0][1]
