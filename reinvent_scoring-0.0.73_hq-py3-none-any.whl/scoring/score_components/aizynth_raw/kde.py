import numpy as np
import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt


plt.figure(figsize=(4, 3), dpi=300)
ax1 = plt.axes([0.18,0.18,0.8,0.8])
fname='chembl_macrocycles_rascore1011.csv'#'chembl_macrocycles'#'3rkz'#'7u99_80'#
# data=pd.read_csv(f'/data/qiuhaodi/software/anaconda/envs/reinvent_ra/lib/python3.7/site-packages/reinvent_scoring/scoring/score_components/aizynth/{fname}_rascore.csv')#,delimiter=','
# data = pd.DataFrame({
#     'value': [1.2, 1.5, 1.7, 2.0, 2.1, 2.5, 2.6, 2.7, 3.0, 3.5, 3.7, 3.9, 4.0]
# })
#data=data['raw_MacroRdkitRMSD']#
#/data/qiuhaodi/software/anaconda/envs/reinvent_ra/lib/python3.7/site-packages/reinvent_scoring/scoring/score_components/aizynth/{fname}_rascore.csv
with open(fname,'r')as f:
    geos = [float(line.strip().split('\t')[-1]) for line in f.readlines()]
# geos =[ geo for geo in geos if geo>0 and geo<100]#list(data)
sns.kdeplot(geos, shade=True,legend=False)
# sc_7u99=3.7115428599811846
# sc_6w50=6.21415636480499
# sc_3rkz=3.501640780593182
plt.axvline(x=2.5, color='r', linestyle='--')
plt.axvline(x=7.5, color='r', linestyle='--')
plt.xticks(np.arange(0,20,2.5))
plt.title('Geometric Distance Distribution')
plt.xlabel('Geometric Distance')
plt.ylabel('Density')
# plt.legend(loc='upper right')
plt.savefig(f'kde_{fname}.png')
plt.show()
