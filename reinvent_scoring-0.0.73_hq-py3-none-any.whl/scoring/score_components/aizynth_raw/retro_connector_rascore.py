from typing import List

import numpy as np

from reinvent_scoring.scoring.component_parameters import ComponentParameters
from reinvent_scoring.scoring.score_components.base_score_component import BaseScoreComponent
from reinvent_scoring.scoring.score_summary import ComponentSummary
from rdkit.Chem import BRICS
import os
import pickle
from rdkit import Chem, DataStructs
# from rdkit.DataStructs import cDataStructs
from rdkit.Chem import AllChem, rdMolDescriptors, FragmentOnBonds, GetMolFrags, MolFromSmiles, MolFromSmarts, MolToSmiles#, FindMolChiralCenters, GetDistanceMatrix
from rdkit.Chem.AllChem import ReplaceSubstructs
# import re
from rdkit.Chem import rdChemReactions as Reactions

default_rxns = [
"[#7;A;H1,H2;!$(NC=O):1].[#6;A:3][#17,#35,#53:2]>>[#6;A:3][#7;A:1]", # 1
"[#7;A;H1,H2;!$(NC=O):1].[n:4]:[c:3]-[F,Cl,Br,I:2]>>[#7;A:1][c:3]:[n:4]", # 2
"[#7;A;H1,H2;!$(NC=O):1].[H:6][#8:5]-[#6:3](-[#6:2])=[O:4]>>[#6:2]-[#6:3]([#7;A:1])=[O:4]", # 3
"[#7;A;H1,H2;!$(NC=O):1].[H:3][#6:2]([#6;A:5])=[O:4]>>[H:3][#6:2]([#6;A:5])[#7;A:1]", # 4
"[#7;A;H1,H2;!$(NC=O):1].[#6;A:5][#6:2]([#6;A:3])=[O:4]>>[#6;A:5][#6:2]([#6;A:3])[#7;A:1]", #5
"[cH1,$(C=C):1].[#6;a:2]-[F,Cl,Br,I:3]>>[#6;a:2]-[cH1,$(C=C):1]", # 6 Heck
"[#6;a:1]-[#8H1:2].[#6;!$(*=O):5][#8,#16;A;H1:4]>>[#6:5]-[#8,#16:4]-[#6;a:1]", # 7 mitsunobu1
"[#6;a:1]-[#8H1:2].[#6;!$(*=O):5][#7;A;H1,H2:4]>>[#6:5]-[#7:4]-[#6;a:1]", # 8 mitsunobu2
"[#6;!$(C=O):1][#8;AH1;!$(OC=O):2].[#6;a:5]-[#17,#35,#53:4]>>[#6;a:5]-[#8:2]-[#6:1]", # 9 couplingO
"[#6;!$(C=O)][#7;A;H1,H2;!$(NC=O):2].[#6;a:5]-[#17,#35,#53:4]>>[#6;a:5]-[#7:2]-[#6:1]", # 10 couplingN
"[#6;!$(C=O)][#16;AH1;!$(SC=O):2].[#6;a:5]-[#17,#35,#53:4]>>[#6;a:5]-[#16:2]-[#6:1]", # 11 couplingS
"[#6;A:1][#17,#35,#53:2].[#6;a:4]-[#17,#35,#53:3]>>[#6;A:1][#6;a:4]", # couplingCC
"[#6;a:1]-[#17,#35,#53:2].[#6;a:4]-[#17,#35,#53:3]>>[#6;a:1]-[#6;a:4]", #couplingCc
"[#7;AH2;!$(NC=O):1].[#17,#35,#53:4][#6;A;!R:7][#7;A;!R:6][#6;A;!R:5][#17,#35,#53:3]>>[#6:7]-1-[#7:6]-[#6:5]-[#7:1]-1", # cycling4
"[#7;AH2;!$(NC=O):1].[#17,#35,#53:4][#6;A;!R:8][#6;A;!R:7][#7;A;!R:6][#6;A;!R:5][#17,#35,#53:3]>>[#6:7]-1-[#6:8]-[#7:1]-[#6:5]-[#7:6]-1", # cycling5
"[#7;AH2;!$(NC=O):1].[#17,#35,#53:4][#6;A;!R:9][#6;A;!R:8][#7;A;!R:7][#6;A;!R:6][#6;A;!R:5][#17,#35,#53:3]>>[#6:8]-1-[#6:9]-[#7:1]-[#6:5]-[#6:6]-[#7:7]-1", #cycling6
"[#6:4]-[#5:2](-[#8:1])-[#8:3].[#6:6]-[F,Cl,Br,I:5]>>[#6:4]-[#6:6]", #BX
"[*:6]-[#7:1]=[N+:2]=[#7-:3].[*:7][C:4]#[CH1:5]>>[*:6]-[#7:1]-1-[#6:5]=[#6:4](-[*:7])-[#7:3]=[#7:2]-1", # clicke triazole
]
retro_rxns_old = [
"[#6;A:3][#7;A:1]>>[#7;A;H1,H2;!$(NC=O):1].[#6;A:3][#17,#35,#53:2]", # 1
"[#7;A:1][c:3]:[n:4]>>[#7;A;H1,H2;!$(NC=O):1].[n:4]:[c:3]-[F,Cl,Br,I:2]", # 2
"[#6:2]-[#6:3]([#7;A:1])=[O:4]>>[#7;A;H1,H2;!$(NC=O):1].[H:6][#8:5]-[#6:3](-[#6:2])=[O:4]", # 3
"[H:3][#6:2]([#6;A:5])[#7;A:1]>>[#7;A;H1,H2;!$(NC=O):1].[H:3][#6:2]([#6;A:5])=[O:4]", # 4
"[#6;A:5][#6:2]([#6;A:3])[#7;A:1]>>[#7;A;H1,H2;!$(NC=O):1].[#6;A:5][#6:2]([#6;A:3])=[O:4]", #5
"[#6;a:2]-[cH1,$(C=C):1]>>[cH1,$(C=C):1].[#6;a:2]-[F,Cl,Br,I:3]", # 6 Heck
"[#6:5]-[#8,#16:4]-[#6;a:1]>>[#6;a:1]-[#8H1:2].[#6;!$(*=O):5][#8,#16;A;H1:4]", # 7 mitsunobu1
"[#6:5]-[#7:4]-[#6;a:1]>>[#6;a:1]-[#8H1:2].[#6;!$(*=O):5][#7;A;H1,H2:4]", # 8 mitsunobu2
"[#6;a:5]-[#8:2]-[#6:1]>>[#6;!$(C=O):1][#8;AH1;!$(OC=O):2].[#6;a:5]-[#17,#35,#53:4]", # 9 couplingO
"[#6;a:5]-[#7:2]-[#6:1]>>[#6;!$(C=O)][#7;A;H1,H2;!$(NC=O):2].[#6;a:5]-[#17,#35,#53:4]", # 10 couplingN
"[#6;a:5]-[#16:2]-[#6:1]>>[#6;!$(C=O)][#16;AH1;!$(SC=O):2].[#6;a:5]-[#17,#35,#53:4]", # 11 couplingS
"[#6;A:1][#6;a:4]>>[#6;A:1][#17,#35,#53:2].[#6;a:4]-[#17,#35,#53:3]", # couplingCC
"[#6;a:1]-[#6;a:4]>>[#6;a:1]-[#17,#35,#53:2].[#6;a:4]-[#17,#35,#53:3]", #couplingCc
"[#6:7]-1-[#7:6]-[#6:5]-[#7:1]-1>>[#7;AH2;!$(NC=O):1].[#17,#35,#53:4][#6;A;!R:7][#7;A;!R:6][#6;A;!R:5][#17,#35,#53:3]", # cycling4
"[#6:7]-1-[#6:8]-[#7:1]-[#6:5]-[#7:6]-1>>[#7;AH2;!$(NC=O):1].[#17,#35,#53:4][#6;A;!R:8][#6;A;!R:7][#7;A;!R:6][#6;A;!R:5][#17,#35,#53:3]", # cycling5
"[#6:8]-1-[#6:9]-[#7:1]-[#6:5]-[#6:6]-[#7:7]-1>>[#7;AH2;!$(NC=O):1].[#17,#35,#53:4][#6;A;!R:9][#6;A;!R:8][#7;A;!R:7][#6;A;!R:6][#6;A;!R:5][#17,#35,#53:3]", #cycling6
"[#6:4]-[#6:6]>>[#6:4]-[#5:2](-[#8:1])-[#8:3].[#6:6]-[F,Cl,Br,I:5]", #BX
"[*:6]-[#7:1]-1-[#6:5]=[#6:4](-[*:7])-[#7:3]=[#7:2]-1>>[*:6]-[#7:1]=[N+:2]=[#7-:3].[*:7][C:4]#[CH1:5]", # clicke triazole
]
new_retro_rxn_ls = []
new_retro_rxn = {'X_nu_substitute':'[C,c:4][N:1]-[C,c:3]>>[C,c:4][NH1,NH2:1].[Cl,Br,I]-[C,c:3]',
'F_nu_substitue':'[C,c:4][N:1]-[c:3]:[n:4]>>[C,c:4][NH1,NH2:1].[F]-[c:3]:[n:4]',
'condensation':'[C,c:2][N:1]-[C:3]=[O:4]>>[C,c:2][NH2,NH1:1].[CX3:3](=[O:4])[OX2H1]',
'condensation':'[C,c:2][N:1]-[S:3]=[O:4]>>[C,c:2][NH2,NH1:1].[SX4:3](=[O:4])[OX2H1]',
'condensation':'[C,c:2][N:1]-[C:3]=[O:4]>>[C,c:2][NH2,NH1:1].[CX3:3](=[O:4])[Cl,Br,I]',
'amination':'[C,c:2][N:1]-[C:3][#6:5]>>[C,c:2][NH2,NH1:1].[CX3H1:3](=O)[#6:5]',
'amination':'[#6:3][CX3:4]([#6:5])[N:1][C,c:2]>>[C,c:2][NH2,NH1:1].[#6:3][CX3:4](=O)[#6:5]',
'mitsunobu':'[C,c:4][N:1]-[c:3]>>[C,c:4][NH1,NH2:1].[c:3]-[OH1]',
'X_nu_substitute':'[C,c:4][N:1]-[C,c:3]>>[Cl,Br,I]-[C,c:3].[C,c:4][NH1,NH2:1]',
'F_nu_substitue':'[C,c:4][N:1]-[c:3]:[n:4]>>[F]-[c:3]:[n:4].[C,c:4][NH1,NH2:1]',
'heck':'[c:1]-[c:2]>>[F,Cl,Br,I:3][c:2].[cH1:1]',
'C-O coupling':'[CX4:1]-[O:2]-[c:5]>>[Cl,Br,I:4][c:5].[CX4:1]-[OH1:2]',
'c-O coupling':'[c:1]-[O:2]-[c:5]>>[Cl,Br,I:4][c:5].[c:1]-[OH1:2]',
'c-c coupling':'[C,c:1]-[c:4]>>[Cl,Br,I:2][C,c:1].[Cl,Br,I:3][c:4]',
'c-c coupling':'[C,c:2]-[C,c:1]>>[Cl,Br,I][C,c:2].[C,c:1]B(O)O',
'condensation':'[C,c:2][N:1]-[C:3]=[O:4]>>[CX3:3](=[O:4])[Cl,Br,I].[C,c:2][NH2,NH1:1]',
'mitsunobu':'[C,c:4][N:1]-[c:3]>>[c:3]-[OH1].[C,c:4][NH1,NH2:1]',
'mitsunobu':'[C,c:4][O:1]-[c:3]>>[c:3]-[OH1].[C,c:4][OH1:1]',
'C-O coupling':'[CX4:1]-[O:2]-[c:5]>>[CX4:1]-[OH1:2].[Cl,Br,I:4][c:5]',
'c-O coupling':'[c:1]-[O:2]-[c:5]>>[c:1]-[OH1:2].[Cl,Br,I:4][c:5]',
'condensation':'[C,c:2][N:1]-[C:3]=[O:4]>>[CX3:3](=[O:4])[OX2H1].[C,c:2][NH2,NH1:1]',
'amination':'[C,c:2][N:1]-[C:3][#6:5]>>[CX3H1:3](=O)[#6:5].[C,c:2][NH2,NH1:1]',
'amination':'[#6:3][CX3:4]([#6:5])[N:1][C,c:2]>>[#6:3][CX3:4](=O)[#6:5].[C,c:2][NH2,NH1:1]',
'c-c coupling':'[C,c:2]-[C,c:1]>>[C,c:1]B(O)O.[Cl,Br,I][C,c:2]',
'click':'[*:6]-[#7:1]-1-[#6:5]=[#6:4](-[*:7])-[#7:3]=[#7:2]-1>>[*:6]-[#7:1]=[N+:2]=[#7-:3].[*:7][C:4]#[C&H1:5]',
'click':'[*:6]-[#7:1]-1-[#6:5]=[#6:4](-[*:7])-[#7:3]=[#7:2]-1>>[*:7][C:4]#[C&H1:5].[*:6]-[#7:1]=[N+:2]=[#7-:3]',
'C#C coupling':'[C,c:1][C:2]#[C:3]-[c:5]>>[Br,I:4][c:5].[C,c:1][C:2]#[C:3]',
'C#C coupling':'[C,c:1][C:2]#[C:3]-[C:5]>>[Cl,Br,I:4][C:5].[C,c:1][C:2]#[C:3]',
'C#C coupling':'[C,c:1][C:2]#[C:3]-[c:5]>>[C,c:1][C:2]#[C:3].[Br,I:4][c:5]',
'C#C coupling':'[C,c:1][C:2]#[C:3]-[C:5]>>[C,c:1][C:2]#[C:3].[Cl,Br,I:4][C:5]'}

class RetroConnectorRAScore(BaseScoreComponent):
    """AiZynth one-step synthesis building block availability.

    Score is the ratio between
    the number of reactants in stock
    and the number of all reactants.

    If a molecule can be synthesized using different reactions,
    with different sets of reactants,
    the maximum ratio is used.

    This scoring component uses AiZynthFinder Expansion interface:
    https://molecularai.github.io/aizynthfinder/python_interface.html#expansion-interface
    """

    def __init__(self, parameters: ComponentParameters):
        super().__init__(parameters)
        # self._xgb_scorer = RAscore_XGB.RAScorerXGB().predict(imatinib_mesylate)
        refsmiles = self.parameters.specific_parameters.get(self.component_specific_parameters.SMILES, [])
        self.refmol = self._chemistry.smile_to_mol(refsmiles)
        HERE = os.path.abspath(os.path.dirname(__file__))
        MODEL = os.path.join(HERE, "model.pkl")
        model_path = self.parameters.specific_parameters.get(self.component_specific_parameters.MODEL_PATH, [])
        if model_path:
            self.xgb_model = pickle.load(open(model_path, "rb"))
        else:
            self.xgb_model = pickle.load(open(MODEL, "rb"))

    def calculate_score(self, molecules: List, step=-1) -> ComponentSummary:
        valid_smiles = self._chemistry.mols_to_smiles(molecules)
        score = self._score_smiles(valid_smiles)  # This is the main calculation.
        score_summary = ComponentSummary(total_score=score, parameters=self.parameters)#, raw_score=score

        return score_summary

    def _score_smiles(self, smiles: List[str]) -> np.ndarray:
        scores = [self._predict_rascore(prbmol) for prbmol in smiles]

        # transform_params = self.parameters.specific_parameters.get(
        #     self.component_specific_parameters.TRANSFORMATION, {}
        # )
        # transformed_scores = self._transformation_function(scores, transform_params)
        return np.array(scores) # np.array(transformed_scores)
        # results = [self._predict_rascore(smi) for smi in smiles]
        #
        # return np.array(results)

    def _predict_rascore(self, smiles):
        # scores = []
        refmol = self.refmol
        prbmol = mw0 = mw1 = fm = Chem.MolFromSmiles(smiles)
        # prbmol = mw0 = mw1 = self._soft_check(mol)
        # matches = prbmol.GetSubstructMatches(refmol, uniquify=True)[0]
        atom_pair_0 = [atom.GetIdx()  for atom in prbmol.GetAtoms() if
                        atom.HasProp("molAtomMapNumber") and atom.GetProp("molAtomMapNumber") == '0']
        atom_pair_1 = [atom.GetIdx() for atom in prbmol.GetAtoms() if
                        atom.HasProp("molAtomMapNumber") and atom.GetProp("molAtomMapNumber") == '1']
        bond_0 = prbmol.GetBondBetweenAtoms(atom_pair_0[0],atom_pair_0[1]).GetIdx()
        bond_1 = prbmol.GetBondBetweenAtoms(atom_pair_1[0],atom_pair_1[1]).GetIdx()
        bond_pair = [bond_0, bond_1]
        # bond_pair = [prbmol.GetBondBetweenAtoms(atom_pair_0[0],atom_pair_0[1]).GetIdx(), prbmol.GetBondBetweenAtoms(atom_pair_1[0],atom_pair_1[1]).GetIdx()]
        # # f0mol = Chem.RWMol(mw0)# as :
        # # f0mol.RemoveBond(atom_pair_0[0],atom_pair_0[1])
        # # f1mol =  Chem.RWMol(mw1)# as mw1:
        # # f1mol.RemoveBond(atom_pair_1[0],atom_pair_1[1])
        # # f0_mol = self._soft_check(f0mol)
        # # f1_mol = self._soft_check(f1mol)
        # # atom.ClearProp("molAtomMapNumber")#,addDummies=False
        f0mol = GetMolFrags(FragmentOnBonds(mw0, [bond_0]), asMols=True)[0]
        f1mol = GetMolFrags(FragmentOnBonds(mw1, [bond_1]), asMols=True)[0]
        f0_mol = Chem.RemoveHs(
            ReplaceSubstructs(f0mol, Chem.MolFromSmiles('*'), Chem.MolFromSmiles('[H]'), True)[0])
        f1_mol = Chem.RemoveHs(
            ReplaceSubstructs(f1mol, Chem.MolFromSmiles('*'), Chem.MolFromSmiles('[H]'), True)[0])
        try:
            fragments = FragmentOnBonds(prbmol, bond_pair)
            fragment_mols = GetMolFrags(fragments, asMols=True)
            lk_mol = [frag  for frag in fragment_mols if not frag.GetSubstructMatches(refmol, uniquify=True)][0]
            lk_atom_pair = [atom.GetIdx() for atom in lk_mol.GetAtoms() if atom.HasProp("molAtomMapNumber")]
            ref_mol = [frag for frag in fragment_mols if frag.GetSubstructMatches(refmol, uniquify=True)][0]
            ref_atom_pair = [atom.GetIdx() for atom in ref_mol.GetAtoms() if atom.HasProp("molAtomMapNumber")]
        except:
            return 0
        lk_rms = Chem.RemoveHs(
            ReplaceSubstructs(lk_mol, Chem.MolFromSmiles('*'), Chem.MolFromSmiles('[H]'), True)[0])
        sc_rms = Chem.RemoveHs(
            ReplaceSubstructs(ref_mol, Chem.MolFromSmiles('*'), Chem.MolFromSmiles('[H]'), True)[0])

        try:
            Chem.SanitizeMol(f0_mol)
            Chem.SanitizeMol(f1_mol)
        except:
            pass
        # sc_fp = AllChem.GetMorganFingerprint(sc_rms, 3, useCounts=True, useFeatures=False)
        # lk_fp = AllChem.GetMorganFingerprint(lk_rms, 3, useCounts=True, useFeatures=False)
        # f0_fp = AllChem.GetMorganFingerprint(f0_mol, 3, useCounts=True, useFeatures=False)
        # f1_fp = AllChem.GetMorganFingerprint(f1_mol, 3, useCounts=True, useFeatures=False)
        # flag_lk = []
        # flag_sc = []
        co_flag = []
        # rxns = [Reactions.ReactionFromSmarts(x) for x in retro_rxns]
        # for rxn in rxns:
        for name0, reaction0 in new_retro_rxn.items():
            rxn0 = Reactions.ReactionFromSmarts(reaction0)
            results0 = rxn0.RunReactants([fm], maxProducts=500)
            if not results0:
                continue
            match_lk=[]
            match_sc=[]
            for reagents0 in results0:
                lk_mat0=[prod0.GetSubstructMatch(lk_rms) for prod0 in reagents0]
                sc_mat0=[prod0.GetSubstructMatch(sc_rms) for prod0 in reagents0]
                if any(lk_mat0) and any(sc_mat0):
                    if len(lk_mat0) == 2 and len(sc_mat0) == 2:
                        try:
                            co_flag = [reag for reag in reaction0 if reag]
                            Chem.SanitizeMol(co_flag[0])
                            Chem.SanitizeMol(co_flag[1])
                        except:
                            continue
                         #
                    elif len(lk_mat0)==1 and len(sc_mat0)==1:
                        for name1, reaction1 in new_retro_rxn.items():
                            rxn1 = Reactions.ReactionFromSmarts(reaction1)
                            results1 = rxn0.RunReactants([reagents1], maxProducts=500)
                            if not results1:
                                continue
                            for reagents1 in results1:
                                lk_mat1 = [prod1.GetSubstructMatch(lk_rms) for prod1 in reagents1]
                                sc_mat1 = [prod1.GetSubstructMatch(sc_rms) for prod1 in reagents1]
                                if any(lk_mat1) and any(sc_mat1):
                                    if len(lk_mat1) == 2 and len(sc_mat1) == 2:
                                        co_flag = list(reagents1)  #
                                    else:
                                        print(Chem.MolToSmiles(reagents1))
                    else:
                        print(Chem.MolToSmiles(reagents0))
            # match_all = sum(match_lk,match_sc)
            # if any(match_all) and any()
            if not co_flag:
                return
            sa_score = []
            for frag in co_flag:

                arr = self._get_ecfp(frag)
                proba = self.xgb_model.predict_proba(arr.reshape(1, -1))
                sa_score.append(proba[0][1])

            # score.append(proba[0][1])
            return sa_score[0]*sa_score[1]  # score

            # for i,reagents0 in enumerate(results0):
            #
            #     for j,prod0 in enumerate(reagents0):
            #         match_lk[i][j] = prod0.GetSubstructMatch(lk_rms)
            #         match_sc[i][j] = prod0.GetSubstructMatch(sc_rms)
            # if match_lk
            # match = [mol.HasSubstructMatch(Chem.MolFromSmarts(subst)) for subst in list_of_SMARTS
            #               if Chem.MolFromSmarts(subst) for reagents0 in results0 for mol in reagents0]
            # for tp0 in reactants0:
            #
            #     for idx, prod0 in enumerate(tp0):
            #         if prod0.GetSubstructMatch(sc_rms) or prod0.GetSubstructMatch(lk_rms):




        #     all_prods0 = list(sum(reactans0,()))
        #     all_prods0 = [prod0 for prod0 in all_prods0 if self._soft_check(prod0)]
        #     for prod0 in all_prods0:
        #         if prod0.GetSubstructMatch(lk_rms) and prod0.GetSubstructMatch(sc_rms):
        #             for name1, reaction1 in new_retro_rxn.items():
        #                 rxn1 = Reactions.ReactionFromSmarts(reaction1)
        #                 reaction1 = rxn1.RunReactants(prod0)
        #                 if not reactans0:
        #                     continue
        #                 all_prods1 = list(sum(reactans1,()))
        #                 all_prods1 = [prod1 for prod1 in all_prods1 if self._soft_check(prod1)]
        #     # prods = list(sum(reactans, ()))
        #     # for prod in prods:
        #     #     prod = self._soft_check(prod)
        #     #     if not prod:
        #     #         continue
        #
        #         if prod.GetSubstructMatch(lk_rms) and prod.GetSubstructMatch(lk_rms) :
        #             co_lk_flag = 1
        #             break
        #
        # if not co_lk_flag:
        #     # print('NO COLINKERS')
        #     return 0
        # try:
        #     Chem.SanitizeMol(lk_rms)
        # except:
        #     return 0
        # arr = self._get_ecfp(lk_rms)
        # proba = self.xgb_model.predict_proba(arr.reshape(1, -1))
        # # score.append(proba[0][1])
        # return proba[0][1]#score

    def _add_connector(self, mol):
        # patt_NOS, patt_CO, patt_Cc = [MolFromSmarts('[Xe;$([N,O,S])]'), MolFromSmarts('[Xe;$(C(=O))]'), MolFromSmarts('[Xe;$([#6])]')]
        # rep_NOS, rep_CO, rep_Cc = [MolFromSmiles('[H]'), MolFromSmiles('[OH]'), MolFromSmiles('[F]')]
        pat_N, pat_O, pat_S, pat_CO, pat_C, pat_c = [MolFromSmarts('[N][Rb]'), MolFromSmarts('[O][Rb]'),
                MolFromSmarts('[S][Rb]'), MolFromSmarts('[C](=O)[Rb]'), MolFromSmarts('[C][Rb]'), MolFromSmarts('[c][Rb]')]
        rep_N, rep_O, rep_S, rep_CO, rep_C, rep_c = [MolFromSmarts('[N][H]'), MolFromSmarts('[O][H]'),
                MolFromSmarts('[S][H]'), MolFromSmarts('[C](=O)[OH]'), MolFromSmarts('[C][F]'), MolFromSmarts('[c][F]')]

        pats = [MolFromSmarts('[N][Rb]'), MolFromSmarts('[O][Rb]'),
                MolFromSmarts('[S][Rb]'), MolFromSmarts('[C](=O)[Rb]'),
                MolFromSmarts('[C][Rb]'), MolFromSmarts('[c][Rb]')]
        reps = [MolFromSmarts('[N][H]'), MolFromSmarts('[O][H]'),
                MolFromSmarts('[S][H]'), MolFromSmarts('[C](=O)[OH]'),
                MolFromSmarts('[C][F]'), MolFromSmarts('[c][F]')]

        while MolToSmiles(mol).count('Rb') > 0:
            # print(f"add wrong:{MolToSmiles(mol)}")
            for pat, rep in zip(pats,reps):
                if mol.GetSubstructMatch(pat):
                    # print(MolToSmiles(pat))
                    mol = ReplaceSubstructs(mol, pat, rep, True, 0)[0]

        co_smiles = MolToSmiles(mol)
        # if co_smiles.count('Rb') > 0:
        #     print(f"replace wrong:{co_smiles}")
        # co_smiles = re.sub(r'\[\S+:\d+\]', '', MolToSmiles(co_mol))
        #     return co_smiles
        # else:
        return co_smiles

    def _perform_rxn(self, lk_smiles, sc_smiles, reactions, full_mol):
        co_linkers = []
        # connectors = [(MolFromSmiles(lk_smi),MolFromSmarts(sc_smi)) for lk_smi in lk_smiles for sc_smi in sc_smiles]
        # fm_fp = AllChem.GetMorganFingerprint(full_mol, 3, useCounts=True, useFeatures=False)
        for name, reaction in new_retro_rxn.items():
            rxn
        rxns =  [Reactions.ReactionFromSmarts(x) for x in reactions]
        for rxn in rxns:
            reactans = rxn.RunReactants((MolFromSmiles(lk_smiles),MolFromSmarts(sc_smiles)), maxProducts=1000)
            if not reactans:
                continue
            prod = reactans[0][0]
            for rxn in rxns:
                    try:
                        Chem.SanitizeMol(prod)
                        print(MolToSmiles(prod))
                    except:
                        continue
                    fp = AllChem.GetMorganFingerprint(prod, 3, useCounts=True, useFeatures=False)
                    if DataStructs.TanimotoSimilarity(fp, fm_fp) > 0.99:
                        print('Congratulations!!!!!!!')
                        co_linkers.append(MolToSmiles(lk_smiles))
        return set(co_linkers)

    def _get_ecfp(self, mol): #smiles):
        """
        Converts SMILES into a counted ECFP6 vector with features.

        :param smiles: SMILES representation of the moelcule of interest
        :type smiles: str
        :return: ECFP6 counted vector with features
        :rtype: np.array
        """
        # mol = Chem.MolFromSmiles(smiles)
        fp = AllChem.GetMorganFingerprint(mol, 3, useCounts=True, useFeatures=False)
        size = 2048
        arr = np.zeros((size,), np.int32)
        for idx, v in fp.GetNonzeroElements().items():
            nidx = idx % size
            arr[nidx] += int(v)
        return arr


    def _soft_check(self, mol):
        if not mol:
            return
        smi = Chem.MolToSmiles(mol)
        return Chem.MolFromSmiles(smi)

        # for atom in mol.GetAtoms():
        #     if atom.HasProp("molAtomMapNumber"):#atom.GetSymbol() == 'Xe':
        #         # rms = ReplaceSubstructs(mol, , repl)
        #         if atom.GetSymbol() =='N':
        #             co_mol = ReplaceSubstructs(mol, pat_N, rep_N, True, 0)[0]
        #         elif atom.GetSymbol() =='O':
        #             co_mol = ReplaceSubstructs(mol, pat_O, rep_O, True, 0)[0]
        #         elif atom.GetSymbol() =='S':
        #             co_mol = ReplaceSubstructs(mol, pat_S, rep_S, True, 0)[0]
        #         else: #if atom.GetSymbol() == 'C':
        #             CO_pairs = mol.GetSubstructMatches(MolFromSmiles('C(=O)'))
        #             CO_ls = [co if isinstance(co,int) else list(sum(CO_pairs, ())) for co in CO_pairs ]
        #             if atom.GetIdx() in CO_ls:
        #                 co_mol = ReplaceSubstructs(mol, pat_CO, rep_CO, True, 0)[0]
        #             else:
        #                 co_mol = ReplaceSubstructs(mol, pat_c, rep_c, True, 0)[0]
        #                 co_mol = ReplaceSubstructs(mol, pat_C, rep_C, True, 0)[0]
        # rms = AllChem.ReplaceSubstructs(mol, , repl)