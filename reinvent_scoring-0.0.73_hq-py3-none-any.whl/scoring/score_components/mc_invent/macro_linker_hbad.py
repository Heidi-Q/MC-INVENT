from typing import List
from itertools import combinations
from reinvent_scoring.scoring.component_parameters import ComponentParameters
from reinvent_scoring.scoring.score_components import BaseScoreComponent
from reinvent_scoring.scoring.score_summary import ComponentSummary

# import time
import numpy as np
# import pandas as pd
# import rdkit
# from rdkit import Chem
# from rdkit import Geometry as rdGeometry
from rdkit.Chem import AddHs, RemoveHs, MolToSmiles, rdMolDescriptors, FragmentOnBonds, GetMolFrags
from rdkit.Chem.AllChem import AlignMol, EmbedMultipleConfs
# import os
# import sys
# import math
# import warnings

class MacroLinkerHBAD(BaseScoreComponent):
    def __init__(self, parameters: ComponentParameters):
        super().__init__(parameters)
        refsmiles = self.parameters.specific_parameters.get(self.component_specific_parameters.SMILES, [])
        self.refmol = self._chemistry.smile_to_mol(refsmiles)

    def calculate_score(self, molecules: List) -> ComponentSummary:
        score, raw_score = self._calculate_score(molecules)
        score_summary = ComponentSummary(total_score=score, parameters=self.parameters, raw_score=raw_score)
        return score_summary

    def _calculate_score(self, query_mols):
        refmol = self.refmol
        scores = [ int(self._calculate_single_score(prbmol,refmol)) for prbmol in query_mols ]
        transform_params = self.parameters.specific_parameters.get(
            self.component_specific_parameters.TRANSFORMATION, {}
        )
        transformed_scores = self._transformation_function(scores, transform_params)
        return np.array(transformed_scores, dtype=np.float32), np.array(scores, dtype=np.float32)#scores

    def _calculate_single_score(self, prbmol, refmol):
        atom_pair_0 = [atom.GetIdx()  for atom in prbmol.GetAtoms() if
                        atom.HasProp("molAtomMapNumber") and atom.GetProp("molAtomMapNumber") == '0']
        atom_pair_1 = [atom.GetIdx() for atom in prbmol.GetAtoms() if
                        atom.HasProp("molAtomMapNumber") and atom.GetProp("molAtomMapNumber") == '1']

        try:
            bond_pair = [prbmol.GetBondBetweenAtoms(atom_pair_0[0], atom_pair_0[1]).GetIdx(),
                         prbmol.GetBondBetweenAtoms(atom_pair_1[0], atom_pair_1[1]).GetIdx()]

            fragments = FragmentOnBonds(prbmol, bond_pair)
            fragments = GetMolFrags(fragments, asMols=True)
            # atom.ClearProp("molAtomMapNumber")
            lkmol = [frag  for frag in fragments if not frag.GetSubstructMatches(refmol, uniquify=True)][0]
        except:
            return False
        lk_hba = rdMolDescriptors.CalcNumHBA(lkmol)
        lk_hbd = rdMolDescriptors.CalcNumHBD(lkmol)
        return lk_hbd #< 3 #and lk_hba < 4 ###20240107

