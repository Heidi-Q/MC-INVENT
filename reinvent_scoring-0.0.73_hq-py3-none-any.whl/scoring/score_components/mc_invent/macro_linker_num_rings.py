from typing import List
import numpy as np
from itertools import combinations
from reinvent_scoring.scoring.component_parameters import ComponentParameters
from reinvent_scoring.scoring.score_components import BaseScoreComponent
from reinvent_scoring.scoring.score_summary import ComponentSummary
from rdkit.Chem import rdMolDescriptors, FragmentOnBonds, GetMolFrags, FindMolChiralCenters, GetDistanceMatrix


class MacroLinkerNumRings(BaseScoreComponent):
    def __init__(self, parameters: ComponentParameters):
        super().__init__(parameters)
        refsmiles = self.parameters.specific_parameters.get(self.component_specific_parameters.SMILES, [])
        self.refmol = self._chemistry.smile_to_mol(refsmiles)

    def calculate_score(self, molecules: List) -> ComponentSummary:
        score, raw_score = self._calculate_score(molecules)
        score_summary = ComponentSummary(total_score=score, parameters=self.parameters, raw_score=raw_score)
        return score_summary

    def _calculate_score(self, query_mols):
        refmol = self.refmol
        # ratio_pair = self.parameters.specific_parameters.get(self.component_specific_parameters.RATIO_PAIR, [])
        scores = [ self._calculate_single_score(prbmol,refmol) for prbmol in query_mols ]
        # reverse = [ 1 - s for s in scores ]
        transform_params = self.parameters.specific_parameters.get(
            self.component_specific_parameters.TRANSFORMATION, {}
        )
        transformed_scores = self._transformation_function(scores, transform_params)
        return np.array(transformed_scores, dtype=np.float32), np.array(scores, dtype=np.float32) # scores

    def _calculate_single_score(self, prbmol, refmol):#, ratio_pair = [0.8, 1.2]
        # match = prbmol.GetSubstructMatch(refmol)#, uniquify=True)[0]
        atom_pair_0 = [atom.GetIdx()  for atom in prbmol.GetAtoms() if
                        atom.HasProp("molAtomMapNumber") and atom.GetProp("molAtomMapNumber") == '0']
        atom_pair_1 = [atom.GetIdx() for atom in prbmol.GetAtoms() if
                        atom.HasProp("molAtomMapNumber") and atom.GetProp("molAtomMapNumber") == '1']

        # atom.ClearProp("molAtomMapNumber")
        try:
            bond_pair = [prbmol.GetBondBetweenAtoms(atom_pair_0[0], atom_pair_0[1]).GetIdx(),
                         prbmol.GetBondBetweenAtoms(atom_pair_1[0], atom_pair_1[1]).GetIdx()]

            fragments = FragmentOnBonds(prbmol, bond_pair)
            fragments = GetMolFrags(fragments, asMols=True)
            lk_mol = [frag  for frag in fragments if not frag.GetSubstructMatches(refmol, uniquify=True)][0]
            # lk_atom_pair = [atom.GetIdx() for atom in lk_mol.GetAtoms() if atom.HasProp("molAtomMapNumber")]
            # ref_mol = [frag for frag in fragments if frag.GetSubstructMatches(refmol, uniquify=True)][0]
            # ref_atom_pair = [atom.GetIdx() for atom in ref_mol.GetAtoms() if atom.HasProp("molAtomMapNumber")]
        except:
            return False
        num_rings = rdMolDescriptors.CalcNumRings(lk_mol)

        # ref_distance_matrix = GetDistanceMatrix(ref_mol)
        # ref_eflength = ref_distance_matrix[ref_atom_pair[0], ref_atom_pair[1]]
        # eflength_ratio = lk_eflength / ref_eflength

        # lk_max_length = distance_matrix.max()

        return num_rings #>= ratio_pair[0] and eflength_ratio <= ratio_pair[1] # and effective_length / max_length > 0.7
