from typing import List
import numpy as np

from reinvent_scoring.scoring.component_parameters import ComponentParameters
from reinvent_scoring.scoring.score_components import BaseScoreComponent
from reinvent_scoring.scoring.score_summary import ComponentSummary

from rdkit.Chem import AddHs, RemoveHs, MolToSmiles, MolFromSmiles, SDMolSupplier, FragmentOnBonds
from rdkit.Chem.AllChem import AlignMol, EmbedMultipleConfs, EmbedMolecule,MMFFGetMoleculeProperties,MMFFGetMoleculeForceField, MMFFOptimizeMolecule

from openeye import oechem, oeshape, oeomega


# sdf_filename = '/data/qiuhaodi/reinvent/Reinvent-master/LIO/OwnRL/8H6P_scaffold.sdf'
# smiles = 'OC1OC2CC(C3=CC(=NN3)NC3=NC(=CC=C3)C(=O)OCOC(=O)N1O)CC2'
# macro = read_conformers(sdf_filename)
# scaff = generate3Dcoordinates(smiles)
# rmsd = calculate_rmsd(scaff, macro)
# print(f"RMSD 值为: {rmsd}")

class MacroOpenEyeRMSD(BaseScoreComponent):
    def __init__(self, parameters: ComponentParameters):
        super().__init__(parameters)
        self.ref_type = self.parameters.specific_parameters.get(self.component_specific_parameters.REF_TYPE, [])

    def calculate_score(self, molecules: List) -> ComponentSummary:
        valid_smiles = self._chemistry.mols_to_smiles(molecules)
        score = self._get_align_rmsd(valid_smiles)
        score_summary = ComponentSummary(total_score=score, parameters=self.parameters)
        return score_summary

    def _get_align_rmsd(self, query_mols):
        if self.ref_type == "sdf":
            ref_path = self.parameters.specific_parameters.get(self.component_specific_parameters.REF_PATH, [])
            reffs = oechem.oemolistream()
            if not reffs.open(ref_path):
                oechem.OEThrow.Fatal("Unable to open %s for reading" % ref_path)
            if not oechem.OEIs3DFormat(reffs.GetFormat()):
                oechem.OEThrow.Fatal("Invalid input format: need 3D coordinates")
            self.ref_mol = oechem.OEGraphMol()
            if not oechem.OEReadMolecule(reffs, self.ref_mol):
                oechem.OEThrow.Fatal("Unable to read molecule in %s" % ref_path)
            if not self.ref_mol.GetDimension() == 3:
                oechem.OEThrow.Fatal("Doesn't have 3D coordinates" )
            scores = [self._calculate_omega_score(query_mol, self.ref_mol) for query_mol in query_mols]
        transform_params = self.parameters.specific_parameters.get(
            self.component_specific_parameters.TRANSFORMATION, {}
        )
        transformed_scores = self._transformation_function(scores, transform_params)
        return transformed_scores


    def _calculate_omega_score(self, smile, refmol) -> np.array:
        max_confs = 4
        omegaOpts = oeomega.OEMacrocycleOmegaOptions()#OEOmegaOptions()
        # omegaOpts.SetStrictStereo(False)
        omegaOpts.SetMaxConfs(max_confs)
        self.omega = oeomega.OEMacrocycleOmega(omegaOpts)
        scores = []
        # for smile in smiles:
        imol = oechem.OEMol()
        # best_score = 100.0
        if oechem.OESmilesToMol(imol, smile):
            # if self.omega(imol):
            omega_success, imol = self._get_omega_confs(imol, self.omega, max_confs)#enum_stereo,
            if omega_success:
                oechem.OESuppressHydrogens(refmol)
                score = self._MCSAlign(refmol, imol)#, ofs)
                scores.append(score)
        return np.array(scores)


    def _get_omega_confs(self, imol, omega, max_stereo):#, enum_stereo, omega
        stereo = False
        # no_stereo = False
        # if enum_stereo:
        enantiomers = list(oeomega.OEFlipper(imol.GetActive(), max_stereo, False, True))
        for k, enantiomer in enumerate(enantiomers):
            # Any other simpler way to combine and add all conformers to imol have failed !!
            # Failure = Creates conformers with wrong indices and wrong connections
            enantiomer = oechem.OEMol(enantiomer)
            ret_code = omega.Build(enantiomer)
            if ret_code == oeomega.OEOmegaReturnCode_Success:
                if k == 0:
                    imol = oechem.OEMol(enantiomer.SCMol())
                    imol.DeleteConfs()
                stereo = True
                for x in enantiomer.GetConfs():
                    imol.NewConf(x)
        # else:
        #     no_stereo = omega(imol)
        return stereo, imol #no_stereo or


    def _MCSAlign(self, refmol, fitmol):#, ofs):
        bestRMS = 100.0
        atomexpr = oechem.OEExprOpts_AtomicNumber | oechem.OEExprOpts_Aromaticity
        bondexpr = 0
        mcss = oechem.OEMCSSearch(oechem.OEMCSType_Exhaustive)
        mcss.Init(refmol, atomexpr, bondexpr)
        mcss.SetMCSFunc(oechem.OEMCSMaxBondsCompleteCycles())

        rmat = oechem.OEDoubleArray(9)
        trans = oechem.OEDoubleArray(3)
        unique = True
        overlay = True
        for match in mcss.Match(fitmol, unique):
            rms = oechem.OERMSD(mcss.GetPattern(), fitmol, match, overlay, rmat, trans)
            if rms < 0.0:
                oechem.OEThrow.Warning("RMS overlay failure")
                continue
            elif rms < bestRMS:
                bestRMS = rms
        return bestRMS
