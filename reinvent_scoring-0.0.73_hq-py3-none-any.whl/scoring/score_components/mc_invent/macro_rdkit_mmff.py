from rdkit.Chem import AddHs, RemoveHs, MolToSmiles, MolFromSmiles, SDMolSupplier, FragmentOnBonds, GetMolFrags
from rdkit.Chem.AllChem import ReplaceSubstructs, EmbedMultipleConfs, EmbedMolecule,MMFFGetMoleculeProperties,MMFFGetMoleculeForceField
from rdkit import Chem
from rdkit.Geometry import rdGeometry
from typing import List
import numpy as np
from reinvent_scoring.scoring.component_parameters import ComponentParameters
from reinvent_scoring.scoring.score_components import BaseScoreComponent
from reinvent_scoring.scoring.score_summary import ComponentSummary
import copy

class MacroRdkitMMFF(BaseScoreComponent):
    def __init__(self, parameters: ComponentParameters):
        super().__init__(parameters)
        self.ref_type = self.parameters.specific_parameters.get(self.component_specific_parameters.REF_TYPE, [])

    def calculate_score(self, molecules: List) -> ComponentSummary:
        score = self._get_mmff_dis(molecules)
        score_summary = ComponentSummary(total_score=score, parameters=self.parameters)
        return score_summary

    def _get_mmff_dis(self, query_mols):
        if self.ref_type == "sdf":
            ref_path = self.parameters.specific_parameters.get(self.component_specific_parameters.REF_PATH, [])
            self.ref_mol = Chem.SDMolSupplier(ref_path)[0]
            scores = [int(self._calculate_sdf_mmff(query_mol, self.ref_mol)) for query_mol in query_mols]
        elif self.ref_type == "smi":
            ref_smi = self.parameters.specific_parameters.get(self.component_specific_parameters.SMILES, [])
            self.ref_mol = self._chemistry.smile_to_mol(ref_smi)
            scores = [self._calculate_smi_mmff(query_mol, self.ref_mol) for query_mol in query_mols]
        else:
            scores = np.full(len(query_mols), 0, dtype=np.float32)

        transform_params = self.parameters.specific_parameters.get(
            self.component_specific_parameters.TRANSFORMATION, {}
        )
        transformed_scores = self._transformation_function(scores, transform_params)

        return transformed_scores

    def _calculate_sdf_mmff(self, prbmol, refmol):
        prbsmi = MolToSmiles(prbmol)
        refsmi = MolToSmiles(refmol)
        bad_return = False
        match_ref = prbmol.GetSubstructMatches(refmol, uniquify=False)[0]
        if not match_ref:
            print(f"{prbsmi} does not match ref-scaffold {refsmi}")
            return bad_return
        #### Get linker ####
        atom_pair_0 = [atom.GetIdx() for atom in prbmol.GetAtoms() if
                       atom.HasProp("molAtomMapNumber") and atom.GetProp("molAtomMapNumber") == '0']
        atom_pair_1 = [atom.GetIdx() for atom in prbmol.GetAtoms() if
                       atom.HasProp("molAtomMapNumber") and atom.GetProp("molAtomMapNumber") == '1']
        bond_pair = [prbmol.GetBondBetweenAtoms(atom_pair_0[0], atom_pair_0[1]).GetIdx(),
                     prbmol.GetBondBetweenAtoms(atom_pair_1[0], atom_pair_1[1]).GetIdx()]
        fragments = FragmentOnBonds(prbmol, bond_pair)
        fragments = GetMolFrags(fragments, asMols=True)
        # atom.ClearProp("molAtomMapNumber")
        try:
            lk_mol = [frag for frag in fragments if not frag.GetSubstructMatches(refmol, uniquify=True)][0]
            for atom in lk_mol.GetAtoms():
                atom.ClearProp("molAtomMapNumber")
            # lk_atom_pair = [atom.GetIdx() for atom in lk_mol.GetAtoms() if atom.HasProp("molAtomMapNumber")]
        except:
            print(f"{prbsmi} has no valid linker for {refsmi}")
            return bad_return
        ##################a

        maps_ref = list(enumerate(match_ref))
        refconf = refmol.GetConformer()  # _adh
        coordsprb = {}
        for idx, pb in maps_ref:
            coordsprb[pb] = refconf.GetAtomPosition(idx)
        prbmol_adh = AddHs(prbmol)
        prbcid = EmbedMolecule(prbmol_adh, coordMap=coordsprb, useMacrocycleTorsions = True)  # useMacrocycleTorsions = True,
        if prbcid == -1:
            print('mmff bad prbconf')
            return bad_return
        else:
            lkmol = RemoveHs(ReplaceSubstructs(lk_mol, Chem.MolFromSmiles('*'), Chem.MolFromSmiles('[H]'), True)[0])
            match_lk = prbmol_adh.GetSubstructMatches(lkmol, uniquify=False)[0]
            if not match_lk:
                lksmi = MolToSmiles(lkmol)
                print(f"{prbsmi} does not match linker {lksmi}")
                return bad_return
            # maps_lk = list(enumerate(match_lk))
            prbconf = prbmol_adh.GetConformer()
            coordslk = {}
            for idx, lk in enumerate(match_lk):
                coordslk[idx] = prbconf.GetAtomPosition(lk)
            lkmol_adh = AddHs(lkmol)
            lkcid = EmbedMolecule(lkmol_adh, coordMap=coordslk )#, coordMap=coordslk, useMacrocycleTorsions = True
            if lkcid == -1:
                print('bad lkconf')
                return bad_return
            else :
                # MMFFOptimizeMolecule(prbmol_adh)
                prbmol_rmh = RemoveHs(prbmol_adh)
                refmol_rmh = RemoveHs(refmol)
                lkmol_rmh = RemoveHs(lkmol_adh)
                try:

                    prb_mmff_props = MMFFGetMoleculeProperties(prbmol_rmh)
                    # prb_mmff_energy = MMFFGetMoleculeForceField(prbmol_adh, prb_mmff_props).CalcEnergy()
                    prb_mmff_energy = MMFFGetMoleculeForceField(prbmol_rmh, prb_mmff_props).CalcEnergy()
                    # ref_mmff_props = MMFFGetMoleculeProperties(refmol)

                    ref_mmff_props = MMFFGetMoleculeProperties(refmol_rmh)
                    # ref_energy = MMFFGetMoleculeForceField(refmol, ref_mmff_props).CalcEnergy()
                    ref_mmff_energy = MMFFGetMoleculeForceField(refmol_rmh, ref_mmff_props).CalcEnergy()
                    # ref_mmff_props = MMFFGetMoleculeProperties(refmol_adh)


                    lk_mmff_props = MMFFGetMoleculeProperties(lkmol_rmh)
                    # lk_mmff_energy = MMFFGetMoleculeForceField(lkmol, lk_mmff_props).CalcEnergy()
                    lk_mmff_energy = MMFFGetMoleculeForceField(lkmol_rmh, lk_mmff_props).CalcEnergy()
                except:
                    print('bad mmff')
                    return bad_return
                mmff_sum = ref_mmff_energy + lk_mmff_energy
                mmff_dis = mmff_sum - prb_mmff_energy

                if mmff_dis >= 0:
                    # print( mmff_dis / mmff_sum )
                    return True
                    # print(dis_ratio)
                else:
                    # print(ref_mmff_energy,lk_mmff_energy,prb_mmff_energy)
                    return bad_return

    def _calculate_smi_mmff(self, prbmol, refmol, numconfpair = [3,10]):
        prbsmi = MolToSmiles(prbmol)
        refsmi = MolToSmiles(refmol)
        mmff_dis = -1
        match = prbmol.GetSubstructMatches(refmol, uniquify=False)[0]
        if not match:
            print(f"{prbsmi} does not match {refsmi}")
            return mmff_dis
        #### Get linker ####
        atom_pair_0 = [atom.GetIdx() for atom in prbmol.GetAtoms() if
                       atom.HasProp("molAtomMapNumber") and atom.GetProp("molAtomMapNumber") == '0']
        atom_pair_1 = [atom.GetIdx() for atom in prbmol.GetAtoms() if
                       atom.HasProp("molAtomMapNumber") and atom.GetProp("molAtomMapNumber") == '1']
        bond_pair = [prbmol.GetBondBetweenAtoms(atom_pair_0[0], atom_pair_0[1]).GetIdx(),
                     prbmol.GetBondBetweenAtoms(atom_pair_1[0], atom_pair_1[1]).GetIdx()]
        fragments = FragmentOnBonds(prbmol, bond_pair)
        fragments = GetMolFrags(fragments, asMols=True)
        # atom.ClearProp("molAtomMapNumber")
        try:
            lk_mol = [frag for frag in fragments if not frag.GetSubstructMatches(refmol, uniquify=True)][0]
            lk_atom_pair = [atom.GetIdx() for atom in lk_mol.GetAtoms() if atom.HasProp("molAtomMapNumber")]
        except:
            print(f"{prbsmi} has no valid linker for {refsmi}")
            return mmff_dis
        ##################

        maps = [list(enumerate(mt)) for mt in match]

        refconf = refmol.GetConformer()  # _adh
        coords = {}
        for idx, pb in maps:
            coords[pb] = refconf.GetAtomPosition(idx)
        prbmol_adh = AddHs(prbmol)
        suc = EmbedMolecule(prbmol_adh, coordMap=coords, useMacrocycleTorsions=True)  # useMacrocycleTorsions = True,
        # prbmol_rmh = RemoveHs(prbmol_adh)
        if suc == -1:
            print('mmff bad prbconf')
        else:
            # MMFFOptimizeMolecule(prbmol_adh)
            prbmol_rmh = RemoveHs(prbmol_adh)
            ref_mmff_props = AllChem.MMFFGetMoleculeProperties(refmol)
            ref_energy = AllChem.MMFFGetMoleculeForceField(refmol, mmff_props).CalcEnergy()
            ref_mmff_props = AllChem.MMFFGetMoleculeProperties(refmol_adh)
            lkmol = AddHs(lk_mol)
            EmbedMolecule(lkmol)
            lk_prop = AllChem.MMFFGetMoleculeProperties(lkmol)
            lk_mmff_energy = AllChem.MMFFGetMoleculeForceField(refmol_adh, mmff_props).CalcEnergy()
            mmff_sum = ref_energy + lk_energy
            mmff_dis = mmff_sum - prb_energy
            if mmff_dis > 0:
                dis_ratio = mmff_dis / mmff_sum
        return dis_ratio

        bestRMS = 100.0
        matches = prbmol.GetSubstructMatches(refmol, uniquify=False)
        if not matches:
            prbsmi = MolToSmiles(prbmol)
            refsmi = MolToSmiles(refmol)
            print(f"{prbsmi} does not match {refsmi}")
            return bestRMS

        maps = [list(enumerate(match)) for match in matches]

        prbmol_adh = AddHs(prbmol)
        prbcids = EmbedMultipleConfs(prbmol_adh, useRandomCoords=True, numConfs=numconfpair[0])
        prbcids = list(prbcids)
        prbmol_rmh = RemoveHs(prbmol_adh)
        # print(prbmol_rmh.GetConformer(3))
        refmol_adh = AddHs(refmol)
        refcids = EmbedMultipleConfs(refmol_adh, useRandomCoords=True, numConfs=numconfpair[1])
        refcids = list(refcids)
        refmol_rmh = RemoveHs(refmol_adh)
        # print(len(refcids))
        # bestRMS = 1000.0
        for amap in maps:
            # print(amap)
            for i in range(len(refcids)):
                for j in range(len(prbcids)):
                    # print(type(i))
                    rms = AlignMol(refmol_rmh, prbmol_rmh, prbCid=i, refCid=j, atomMap=amap)
                    if rms < bestRMS:
                        bestRMS = rms
        '''
                        bestPrbCid = i
                        bestRefCid = j

        # Save the best aligned conformers to an SDF file named by the SMILES of prbmol
        writer = Chem.SDWriter(Chem.MolToSmiles(prbmol) + ".sdf")
        writer.write(prbmol_rmh, bestPrbCid)
        writer.write(refmol_rmh, bestRefCid)
        writer.close()
        '''
        return bestRMS


