from typing import List
from itertools import combinations
from reinvent_scoring.scoring.component_parameters import ComponentParameters
from reinvent_scoring.scoring.score_components import BaseScoreComponent
from reinvent_scoring.scoring.score_summary import ComponentSummary

# import time
# import numpy as np
# import pandas as pd
# import rdkit
# from rdkit import Chem
# from rdkit import Geometry as rdGeometry
from rdkit.Chem import rdMolDescriptors, FragmentOnBonds, GetMolFrags, GetDistanceMatrix
# import os
# import sys
# import math
# import warnings

class MacroLinkerLR(BaseScoreComponent):
    def __init__(self, parameters: ComponentParameters):
        super().__init__(parameters)
        refsmiles = self.parameters.specific_parameters.get(self.component_specific_parameters.SMILES, [])
        self.refmol = self._chemistry.smile_to_mol(refsmiles)

    def calculate_score(self, molecules: List) -> ComponentSummary:
        score = self._calculate_score(molecules)
        score_summary = ComponentSummary(total_score=score, parameters=self.parameters)
        return score_summary

    def _calculate_score(self, query_mols):
        refmol = self.refmol
        scores = [ int(self._calculate_single_score(prbmol,refmol)) for prbmol in query_mols ]
        # reverse = [ 1 - s for s in scores ]
        # transform_params = self.parameters.specific_parameters.get(
        #     self.component_specific_parameters.TRANSFORMATION, {}
        # )
        # transformed_scores = self._transformation_function(scores, transform_params)
        return scores

    def _calculate_single_score(self, prbmol, refmol):
        match = prbmol.GetSubstructMatches(refmol, uniquify=True)[0]
        atom_pair_0 = [atom.GetIdx()  for atom in prbmol.GetAtoms() if
                        atom.HasProp("molAtomMapNumber") and atom.GetProp("molAtomMapNumber") == '0']
        atom_pair_1 = [atom.GetIdx() for atom in prbmol.GetAtoms() if
                        atom.HasProp("molAtomMapNumber") and atom.GetProp("molAtomMapNumber") == '1']
        bond_pair = [ prbmol.GetBondBetweenAtoms(atom_pair_0[0],atom_pair_0[1]).GetIdx(), prbmol.GetBondBetweenAtoms(atom_pair_1[0],atom_pair_1[1]).GetIdx()]
        fragments = FragmentOnBonds(prbmol, bond_pair)
        fragments = GetMolFrags(fragments, asMols=True)
        # atom.ClearProp("molAtomMapNumber")
        try:
            lk_mol = [frag  for frag in fragments if not frag.GetSubstructMatches(refmol, uniquify=True)][0]
            lk_atom_pair = [atom.GetIdx() for atom in lk_mol.GetAtoms() if atom.HasProp("molAtomMapNumber")]
        except:
            return False


        distance_matrix = GetDistanceMatrix(lk_mol)
        max_length = distance_matrix.max()
        effective_length = distance_matrix[lk_atom_pair[0], lk_atom_pair[1]]

        return effective_length / max_length > 0.7


    # def _calculate_rmsd(self, prbmol, refmol):
    #     # print(Chem.MolToSmiles(prbmol))
    #     # print(Chem.MolToSmiles(refmol))
    #     bestRMS = 1.0
    #     matches = prbmol.GetSubstructMatches(refmol, uniquify=False)
    #     if not matches:
    #         prbsmi = MolToSmiles(prbmol)
    #         refsmi = MolToSmiles(refmol)
    #         print(f"{prbsmi} does not match {refsmi}")
    #         return bestRMS
    #
    #     maps = [list(enumerate(match)) for match in matches]
    #
    #     prbmol_adh = AddHs(prbmol)
    #     prbcids = EmbedMultipleConfs(prbmol_adh, useRandomCoords=True, numConfs=3)
    #     prbcids = list(prbcids)
    #     prbmol_rmh = RemoveHs(prbmol_adh)
    #     # print(prbmol_rmh.GetConformer(3))
    #     refmol_adh = AddHs(refmol)
    #     refcids = EmbedMultipleConfs(refmol_adh, useRandomCoords=True, numConfs=10)
    #     refcids = list(refcids)
    #     refmol_rmh = RemoveHs(refmol_adh)
    #     # print(len(refcids))
    #     #bestRMS = 1000.0
    #     for amap in maps:
    #         # print(amap)
    #         for i in range(len(refcids)):
    #             for j in range(len(prbcids)):
    #                 # print(type(i))
    #                 rms = AlignMol(refmol_rmh, prbmol_rmh, prbCid=i, refCid=j, atomMap=amap)
    #                 if rms < bestRMS:
    #                     bestRMS = rms
    #     '''
    #                     bestPrbCid = i
    #                     bestRefCid = j
    #
    #     # Save the best aligned conformers to an SDF file named by the SMILES of prbmol
    #     writer = Chem.SDWriter(Chem.MolToSmiles(prbmol) + ".sdf")
    #     writer.write(prbmol_rmh, bestPrbCid)
    #     writer.write(refmol_rmh, bestRefCid)
    #     writer.close()
    #     '''
    #     return 1-bestRMS
