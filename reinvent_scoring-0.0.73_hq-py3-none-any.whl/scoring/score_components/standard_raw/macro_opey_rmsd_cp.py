# from typing import List
# import numpy as np
#
# from reinvent_scoring.scoring.component_parameters import ComponentParameters
# from reinvent_scoring.scoring.score_components import BaseScoreComponent
# from reinvent_scoring.scoring.score_summary import ComponentSummary
#
# from rdkit.Chem import AddHs, RemoveHs, MolToSmiles, MolFromSmiles, SDMolSupplier, FragmentOnBonds
# from rdkit.Chem.AllChem import AlignMol, EmbedMultipleConfs, EmbedMolecule,MMFFGetMoleculeProperties,MMFFGetMoleculeForceField, MMFFOptimizeMolecule
#
#
# class MacroOpeneyeRMSD(BaseScoreComponent):
#     def __init__(self, parameters: ComponentParameters):
#         super().__init__(parameters)
#         self.ref_type = self.parameters.specific_parameters.get(self.component_specific_parameters.REF_TYPE, [])
#
#     def calculate_score(self, molecules: List) -> ComponentSummary:
#         score = self._get_align_rmsd(molecules)
#         score_summary = ComponentSummary(total_score=score, parameters=self.parameters)
#         return score_summary
#
#     def _get_align_rmsd(self, query_mols):
#         if self.ref_type == "sdf":
#             ref_path = self.parameters.specific_parameters.get(self.component_specific_parameters.REF_PATH, [])
#             self.ref_mol = SDMolSupplier(ref_path)[0]
#             scores = [self._calculate_sdf_rmsd(query_mol, self.ref_mol) for query_mol in query_mols]
#         elif self.ref_type == "smi":
#             ref_smi = self.parameters.specific_parameters.get(self.component_specific_parameters.SMILES, [])
#             self.ref_mol = self._chemistry.smile_to_mol(ref_smi)
#             numconfpair = self.parameters.specific_parameters.get(self.component_specific_parameters.NUM_CONF_PAIR, [])
#             scores = [self._calculate_smi_rmsd(query_mol, self.ref_mol) for query_mol in query_mols]
#         else:
#             scores = np.full(len(query_mols), 0, dtype=np.float32)
#         transform_params = self.parameters.specific_parameters.get(
#             self.component_specific_parameters.TRANSFORMATION, {}
#         )
#         transformed_scores = self._transformation_function(scores, transform_params)
#         return transformed_scores
#
#     def _calculate_smi_rmsd(self, prbmol, refmol, numconfpair=[3, 10]):
#         bestRMS = 100.0
#         matches = prbmol.GetSubstructMatches(refmol, uniquify=False)
#         if not matches:
#             prbsmi = MolToSmiles(prbmol)
#             refsmi = MolToSmiles(refmol)
#             print(f"{prbsmi} does not match {refsmi}")
#             return bestRMS
#
#         maps = [list(enumerate(match)) for match in matches]
#         refconf = refmol.GetConformer()  # _adh
#         coords = {}
#         for idx, pb in maps:
#             coords[pb] = refconf.GetAtomPosition(idx)
#         prbmol_adh = AddHs(prbmol)
#         prbcids = EmbedMultipleConfs(prbmol_adh, useRandomCoords=True, numConfs=numconfpair[0])
#         prbcids = list(prbcids)
#         prbmol_rmh = RemoveHs(prbmol_adh)
#         refmol_adh = AddHs(refmol)
#         refcids = EmbedMultipleConfs(refmol_adh, useRandomCoords=True, numConfs=numconfpair[1])
#         refcids = list(refcids)
#         refmol_rmh = RemoveHs(refmol_adh)
#
#         for amap in maps:
#             for i in range(len(refcids)):
#                 for j in range(len(prbcids)):
#                     rms = AlignMol(refmol_rmh, prbmol_rmh, prbCid=i, refCid=j, atomMap=amap)
#                     rms1 = AlignMol(refmol_adh, prbmol_adh, prbCid=i, refCid=j, atomMap=amap)
#                     print(rms,rms1)
#                     if rms < bestRMS:
#                         bestRMS = rms
#         '''
#                         bestPrbCid = i
#                         bestRefCid = j
#
#         # Save the best aligned conformers to an SDF file named by the SMILES of prbmol
#         writer = Chem.SDWriter(Chem.MolToSmiles(prbmol) + ".sdf")
#         writer.write(prbmol_rmh, bestPrbCid)
#         writer.write(refmol_rmh, bestRefCid)
#         writer.close()
#         '''
#         return bestRMS
#
#     def _calculate_sdf_rmsd(self, prbmol, refmol):
#         bestRMS = 100.0
#         match = prbmol.GetSubstructMatches(refmol, uniquify=False)[0]
#         if not match:
#             prbsmi = MolToSmiles(prbmol)
#             refsmi = MolToSmiles(refmol)
#             print(f"{prbsmi} does not match {refsmi}")
#             return bestRMS
#
#         maps = list(enumerate(match))
#         refconf = refmol.GetConformer()  # _adh
#         coords = {}
#         for idx, pb in maps:
#             coords[pb] = refconf.GetAtomPosition(idx)
#         prbmol_adh = AddHs(prbmol)
#         suc = EmbedMolecule(prbmol_adh, coordMap=coords, useMacrocycleTorsions = True)  # useMacrocycleTorsions = True,
#         # prbmol_rmh = RemoveHs(prbmol_adh)
#         if suc == -1:
#             print('rmsd bad prbconf')
#         else :
#             MMFFOptimizeMolecule(prbmol_adh)
#             prbmol_rmh = RemoveHs(prbmol_adh)
#             rms = AlignMol(refmol, prbmol_rmh, refCid=0, prbCid=0, atomMap=maps)
#             if rms < bestRMS:
#                 bestRMS = rms
#         return bestRMS
# from openeye import oechem, oeszybki
# 
# # 读取分子结构
# mol1 = oechem.OEMol()
# mol2 = oechem.OEMol()
# oechem.OEParseMolecule(mol1, "mol1.sdf")
# oechem.OEParseMolecule(mol2, "mol2.sdf")
# 
# # 计算RMSD
# RMSD = oeszybki.OERMSD(mol1, mol2)
# 
# print("RMSD:", RMSD)

