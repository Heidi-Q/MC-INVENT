import openeye.oechem as oechem
import openeye.oeomega as oeomega
import openeye.oemolprop as oemolprop
import openeye.oeshape as oeshape

def generate_macro_conf(smiles):
    buildOpts = oeomega.OEMacrocycleBuilderOptions()
    buildOpts.SetParameterVisibility(oechem.OEParamVisibility_Hidden)
    buildOpts.SetParameterVisibility("-seed", oechem.OEParamVisibility_Simple)
    buildOpts.SetParameterVisibility("-dielectric_constant", oechem.OEParamVisibility_Simple)

    inType = oechem.OEFileStringType_Mol
    outType = oechem.OEFileStringType_Mol3D
    opts = oechem.OESimpleAppOptions(buildOpts, "macrocycle_builder", inType, outType)
    buildOpts.UpdateValues(opts)
    builder = oeomega.OEMacrocycleBuilder(buildOpts)

    mol = oechem.OEMol()
    oechem.OESmilesToMol(mol, smiles)
    ret_code = builder.Build(mol)
    if ret_code == oeomega.OEOmegaReturnCode_Success:
        print('success!')
    else:
        print('failure!')
    return mol


def read_conformers(file_path):
    ifs = oechem.oemolistream(sdf_filename)
    molecule = oechem.OEGraphMol()
    ifs.SetFormat(oechem.OEFormat_SDF)
    if oechem.OEReadMolecule(ifs, molecule):
        ifs.close()
    else:
        ifs.close()
        raise ValueError("无法从SDF文件中读取分子")
    return molecule


def generate3Dcoordinates(smiles):
    """Method to generate 3D coordinates, in case the molecules have been built from SMILES."""
    oe_molecule = oechem.OEMol()
    oechem.OESmilesToMol(oe_molecule, smiles)
    if oe_molecule is None:
        return
    builder = oeomega.OEConformerBuilder()
    return_code = builder.Build(oe_molecule)
    for conf in oe_molecule.GetConfs():
        for atom in conf.GetAtoms():
            print(f"原子 {atom.GetIdx()}")#: X={atom.GetX()}, Y={atom.GetY()}, Z={atom.GetZ()}")
    if return_code != oeomega.OEOmegaReturnCode_Success:
        return
    return oe_molecule

def SmartsAlign(refmol, fitmol, ss, ofs):
    unique = True
    for match1 in ss.Match(refmol, unique):
        for match2 in ss.Match(fitmol, unique):
            match = oechem.OEMatch()
            for mp1, mp2 in zip(match1.GetAtoms(), match2.GetAtoms()):
                match.AddPair(mp1.target, mp2.target)

            overlay = True
            rmat = oechem.OEDoubleArray(9)
            trans = oechem.OEDoubleArray(3)
            oechem.OERMSD(refmol, fitmol, match, overlay, rmat, trans)
            oechem.OERotate(fitmol, rmat)
            oechem.OETranslate(fitmol, trans)
            oechem.OEWriteConstMolecule(ofs, fitmol)


def main(argv=[__name__]):
    if len(argv) != 5:
        oechem.OEThrow.Usage("%s <refmol> <fitmol> <outfile> <smarts>" % argv[0])

    reffs = oechem.oemolistream()
    if not reffs.open(argv[1]):
        oechem.OEThrow.Fatal("Unable to open %s for reading" % argv[1])
    if not oechem.OEIs3DFormat(reffs.GetFormat()):
        oechem.OEThrow.Fatal("Invalid input format: need 3D coordinates")
    refmol = oechem.OEGraphMol()
    if not oechem.OEReadMolecule(reffs, refmol):
        oechem.OEThrow.Fatal("Unable to read molecule in %s" % argv[1])
    if not refmol.GetDimension() == 3:
        oechem.OEThrow.Fatal("%s doesn't have 3D coordinates" % refmol.GetTitle())

    fitfs = oechem.oemolistream()
    if not fitfs.open(argv[2]):
        oechem.OEThrow.Fatal("Unable to open %s for reading" % argv[2])
    if not oechem.OEIs3DFormat(fitfs.GetFormat()):
        oechem.OEThrow.Fatal("Invalid input format: need 3D coordinates")

    ofs = oechem.oemolostream()
    if not ofs.open(argv[3]):
        oechem.OEThrow.Fatal("Unable to open %s for writing" % argv[3])
    if not oechem.OEIs3DFormat(ofs.GetFormat()):
        oechem.OEThrow.Fatal("Invalid output format: need 3D coordinates")

    oechem.OEWriteConstMolecule(ofs, refmol)

    ss = oechem.OESubSearch()
    if not ss.Init(argv[4]):
        oechem.OEThrow.Fatal("Unable to parse SMARTS: %s" % argv[4])

    oechem.OEPrepareSearch(refmol, ss)
    if not ss.SingleMatch(refmol):
        oechem.OEThrow.Fatal("SMARTS fails to match refmol")

    for fitmol in fitfs.GetOEGraphMols():
        if not fitmol.GetDimension() == 3:
            oechem.OEThrow.Warning("%s doesn't have 3D coordinates" % fitmol.GetTitle())
            continue
        oechem.OEPrepareSearch(fitmol, ss)
        if not ss.SingleMatch(fitmol):
            oechem.OEThrow.Warning("SMARTS fails to match fitmol %s" % fitmol.GetTitle())
            continue
        SmartsAlign(refmol, fitmol, ss, ofs)

def calc_smarts_align(refmol, fitmol, ss, ofs):
    ss = oechem.OESubSearch()
    oechem.OEPrepareSearch(refmol, ss)
    if not ss.SingleMatch(refmol):
        oechem.OEThrow.Fatal("SMARTS fails to match refmol")
        return
    oechem.OEPrepareSearch(fitmol, ss)
    if not ss.SingleMatch(fitmol):
        oechem.OEThrow.Warning("SMARTS fails to match fitmol %s" % fitmol)
        return
    unique = True
    for match1 in ss.Match(refmol, unique):
        for match2 in ss.Match(fitmol, unique):
            match = oechem.OEMatch()
            for mp1, mp2 in zip(match1.GetAtoms(), match2.GetAtoms()):
                match.AddPair(mp1.target, mp2.target)

            overlay = True
            rmat = oechem.OEDoubleArray(9)
            trans = oechem.OEDoubleArray(3)
            rmsd = oechem.OERMSD(refmol, fitmol, match, overlay, rmat, trans)
            oechem.OERotate(fitmol, rmat)
            oechem.OETranslate(fitmol, trans)
            # oechem.OEWriteConstMolecule(ofs, fitmol)
    return rmsd



# oechem.OERotate()
sdf_filename = '/data/qiuhaodi/reinvent/Reinvent-master/LIO/OwnRL/2J9M_scaffold.sdf'
smiles = 'OC1OC2CC(C3=CC(=NN3)NC3=NC(=CC=C3)C(=O)OCOC(=O)N1O)CC2'
macro_smi=('O=C1CCNC(=O)CCNS(=O)(=O)Nc2nc(ncc2Br)Nc2cccc(c2)OCCN1')
# macro = read_conformers(sdf_filename)
macro=generate_macro_conf(macro_smi)
# scaff = generate3Dcoordinates(smiles)
macro2=generate_macro_conf('CC1(C)CSNc2nc(ncc2Br)Nc2cccc(c2)S(=O)(=O)N2CCN1CC2')
# smi_2j9m='Brc1cnc(Nc2ccccc2)nc1'
smi_2j9m='Brc1c([*])nc(Nc2cc([*])ccc2)nc1'
scaff = read_conformers(sdf_filename)
# rmsd = calculate_rmsd(scaff, macro)
# rmsd = oechem.OERMSD(macro2, macro)
out_filepath = '/data/qiuhaodi/reinvent/Reinvent-master-copy/RMSD_curve/2J9M_macro.sdf'
rmsd = calc_smarts_align(macro,macro2,smi_2j9m,out_filepath)
print(f"RMSD 值为: {rmsd}")
